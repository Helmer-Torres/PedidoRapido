"use client"

import { useState } from "react"
import { OrdersTable } from "@/components/pedidos/orders-table"
import { OrderFilters } from "@/components/pedidos/order-filters"
import { SearchInput } from "@/components/shared/search-input"
import { ExportCSVButton } from "@/components/shared/export-csv-button"
import { orders, dashboardStats } from "@/lib/mock-data"
import { exportOrdersToCSV } from "@/lib/export-csv"
import { StatsCard } from "@/components/dashboard/stats-card"
import type { OrderStatus } from "@/lib/types"

type FilterOption = OrderStatus | "todos"

export default function PedidosPage() {
  const [activeFilter, setActiveFilter] = useState<FilterOption>("todos")
  const [searchQuery, setSearchQuery] = useState("")

  const filteredOrders = orders
    .filter(order => activeFilter === "todos" || order.status === activeFilter)
    .filter(order => 
      searchQuery === "" || 
      order.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.clientName.toLowerCase().includes(searchQuery.toLowerCase())
    )

  const filterCounts = {
    todos: orders.length,
    pendiente: orders.filter(o => o.status === "pendiente").length,
    entregado: orders.filter(o => o.status === "entregado").length,
  }

  const handleExport = () => {
    exportOrdersToCSV(filteredOrders, `pedidos-${new Date().toISOString().split("T")[0]}`)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-foreground">Gestión de Pedidos</h1>
        <ExportCSVButton onExport={handleExport} />
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <StatsCard
          title="Total Hoy"
          value={dashboardStats.ordersToday}
          change={dashboardStats.ordersTodayChange}
        />
        <StatsCard
          title="Pendientes"
          value={dashboardStats.pendingOrders}
          subtitle="Acción Requerida"
        />
        <StatsCard
          title="En Proceso"
          value={dashboardStats.inProcessOrders}
        />
      </div>

      <div className="space-y-4">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <h2 className="text-lg font-semibold text-foreground">Lista de Pedidos</h2>
          <div className="flex items-center gap-3">
            <OrderFilters 
              activeFilter={activeFilter} 
              onFilterChange={setActiveFilter}
              counts={filterCounts}
            />
            <SearchInput 
              placeholder="Buscar pedido..."
              value={searchQuery}
              onChange={setSearchQuery}
              className="w-48"
            />
          </div>
        </div>

        <OrdersTable orders={filteredOrders} />
      </div>
    </div>
  )
}
