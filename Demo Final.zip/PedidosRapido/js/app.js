// ===================== SEED DATA =====================
const SEED = {
  products: [
    { id: "PROD-001", name: "Tacos al Pastor", price: 35, category: "Comida", stock: 100 },
    { id: "PROD-002", name: "Tacos de Carnitas", price: 32, category: "Comida", stock: 100 },
    { id: "PROD-003", name: "Tacos de Barbacoa", price: 38, category: "Comida", stock: 80 },
    { id: "PROD-004", name: "Quesadillas", price: 28, category: "Comida", stock: 150 },
    { id: "PROD-005", name: "Guacamole", price: 45, category: "Entrada", stock: 50 },
    { id: "PROD-006", name: "Refresco de Cola", price: 18, category: "Bebida", stock: 200 },
    { id: "PROD-007", name: "Agua de Horchata", price: 15, category: "Bebida", stock: 200 },
    { id: "PROD-008", name: "Flan Napolitano", price: 25, category: "Postre", stock: 40 }
  ],
  clients: [
    { id: "CLI-001", name: "María García", email: "maria@email.com", phone: "55-1234-5678", location: "Ciudad de México", memberSince: "2024-01-15", tier: "vip", totalSpent: 12500, totalOrders: 24, lastOrderDate: "2025-05-25" },
    { id: "CLI-002", name: "Juan Pérez", email: "juan@email.com", phone: "55-2345-6789", location: "Monterrey", memberSince: "2024-03-20", tier: "premium", totalSpent: 8500, totalOrders: 15, lastOrderDate: "2025-05-20" },
    { id: "CLI-003", name: "Ana López", email: "ana@email.com", phone: "55-3456-7890", location: "Guadalajara", memberSince: "2024-06-10", tier: "regular", totalSpent: 3200, totalOrders: 8, lastOrderDate: "2025-05-18" },
    { id: "CLI-004", name: "Carlos Martínez", email: "carlos@email.com", phone: "55-4567-8901", location: "Puebla", memberSince: "2024-02-05", tier: "vip", totalSpent: 18900, totalOrders: 32, lastOrderDate: "2025-05-26" },
    { id: "CLI-005", name: "Sofía Hernández", email: "sofia@email.com", phone: "55-5678-9012", location: "Querétaro", memberSince: "2024-08-12", tier: "premium", totalSpent: 6700, totalOrders: 11, lastOrderDate: "2025-05-15" },
    { id: "CLI-006", name: "Miguel Torres", email: "miguel@email.com", phone: "55-6789-0123", location: "Tijuana", memberSince: "2024-04-28", tier: "regular", totalSpent: 1800, totalOrders: 5, lastOrderDate: "2025-05-10" },
    { id: "CLI-007", name: "Laura Ramírez", email: "laura@email.com", phone: "55-7890-1234", location: "Mérida", memberSince: "2024-09-01", tier: "premium", totalSpent: 9400, totalOrders: 17, lastOrderDate: "2025-05-22" },
    { id: "CLI-008", name: "Roberto Sánchez", email: "roberto@email.com", phone: "55-8901-2345", location: "Cancún", memberSince: "2024-11-15", tier: "regular", totalSpent: 2500, totalOrders: 6, lastOrderDate: "2025-05-24" }
  ],
  orders: [
    { id: "ORD-001", clientId: "CLI-001", clientName: "María García", products: [
      { id: "PROD-001", name: "Tacos al Pastor", quantity: 4, unitPrice: 35, subtotal: 140 },
      { id: "PROD-003", name: "Tacos de Barbacoa", quantity: 3, unitPrice: 38, subtotal: 114 },
      { id: "PROD-006", name: "Refresco de Cola", quantity: 2, unitPrice: 18, subtotal: 36 }
    ], subtotal: 290, tax: 46.40, total: 336.40, status: "entregado", notes: "", createdAt: "2025-05-26T13:30:00", updatedAt: "2025-05-26T14:00:00" },
    { id: "ORD-002", clientId: "CLI-004", clientName: "Carlos Martínez", products: [
      { id: "PROD-002", name: "Tacos de Carnitas", quantity: 5, unitPrice: 32, subtotal: 160 },
      { id: "PROD-005", name: "Guacamole", quantity: 1, unitPrice: 45, subtotal: 45 },
      { id: "PROD-007", name: "Agua de Horchata", quantity: 3, unitPrice: 15, subtotal: 45 },
      { id: "PROD-008", name: "Flan Napolitano", quantity: 2, unitPrice: 25, subtotal: 50 }
    ], subtotal: 300, tax: 48, total: 348, status: "entregado", notes: "", createdAt: "2025-05-26T12:00:00", updatedAt: "2025-05-26T12:45:00" },
    { id: "ORD-003", clientId: "CLI-003", clientName: "Ana López", products: [
      { id: "PROD-004", name: "Quesadillas", quantity: 3, unitPrice: 28, subtotal: 84 },
      { id: "PROD-006", name: "Refresco de Cola", quantity: 1, unitPrice: 18, subtotal: 18 }
    ], subtotal: 102, tax: 16.32, total: 118.32, status: "pendiente", notes: "Sin cebolla por favor", createdAt: "2025-05-26T10:15:00", updatedAt: "2025-05-26T10:15:00" },
    { id: "ORD-004", clientId: "CLI-002", clientName: "Juan Pérez", products: [
      { id: "PROD-001", name: "Tacos al Pastor", quantity: 6, unitPrice: 35, subtotal: 210 },
      { id: "PROD-007", name: "Agua de Horchata", quantity: 2, unitPrice: 15, subtotal: 30 }
    ], subtotal: 240, tax: 38.40, total: 278.40, status: "en_proceso", notes: "Mucha salsa verde", createdAt: "2025-05-26T09:30:00", updatedAt: "2025-05-26T09:45:00" },
    { id: "ORD-005", clientId: "CLI-005", clientName: "Sofía Hernández", products: [
      { id: "PROD-003", name: "Tacos de Barbacoa", quantity: 4, unitPrice: 38, subtotal: 152 },
      { id: "PROD-008", name: "Flan Napolitano", quantity: 1, unitPrice: 25, subtotal: 25 },
      { id: "PROD-006", name: "Refresco de Cola", quantity: 1, unitPrice: 18, subtotal: 18 }
    ], subtotal: 195, tax: 31.20, total: 226.20, status: "entregado", notes: "", createdAt: "2025-05-25T18:00:00", updatedAt: "2025-05-25T18:30:00" },
    { id: "ORD-006", clientId: "CLI-007", clientName: "Laura Ramírez", products: [
      { id: "PROD-002", name: "Tacos de Carnitas", quantity: 3, unitPrice: 32, subtotal: 96 },
      { id: "PROD-004", name: "Quesadillas", quantity: 2, unitPrice: 28, subtotal: 56 },
      { id: "PROD-005", name: "Guacamole", quantity: 1, unitPrice: 45, subtotal: 45 },
      { id: "PROD-007", name: "Agua de Horchata", quantity: 2, unitPrice: 15, subtotal: 30 }
    ], subtotal: 227, tax: 36.32, total: 263.32, status: "en_proceso", notes: "Orden para llevar", createdAt: "2025-05-25T15:00:00", updatedAt: "2025-05-25T15:15:00" },
    { id: "ORD-007", clientId: "CLI-001", clientName: "María García", products: [
      { id: "PROD-001", name: "Tacos al Pastor", quantity: 8, unitPrice: 35, subtotal: 280 },
      { id: "PROD-006", name: "Refresco de Cola", quantity: 4, unitPrice: 18, subtotal: 72 }
    ], subtotal: 352, tax: 56.32, total: 408.32, status: "entregado", notes: "", createdAt: "2025-05-24T20:00:00", updatedAt: "2025-05-24T20:30:00" },
    { id: "ORD-008", clientId: "CLI-008", clientName: "Roberto Sánchez", products: [
      { id: "PROD-003", name: "Tacos de Barbacoa", quantity: 2, unitPrice: 38, subtotal: 76 },
      { id: "PROD-006", name: "Refresco de Cola", quantity: 1, unitPrice: 18, subtotal: 18 }
    ], subtotal: 94, tax: 15.04, total: 109.04, status: "pendiente", notes: "", createdAt: "2025-05-24T19:00:00", updatedAt: "2025-05-24T19:00:00" },
    { id: "ORD-009", clientId: "CLI-004", clientName: "Carlos Martínez", products: [
      { id: "PROD-004", name: "Quesadillas", quantity: 5, unitPrice: 28, subtotal: 140 },
      { id: "PROD-005", name: "Guacamole", quantity: 2, unitPrice: 45, subtotal: 90 },
      { id: "PROD-007", name: "Agua de Horchata", quantity: 4, unitPrice: 15, subtotal: 60 },
      { id: "PROD-008", name: "Flan Napolitano", quantity: 3, unitPrice: 25, subtotal: 75 }
    ], subtotal: 365, tax: 58.40, total: 423.40, status: "entregado", notes: "Todo bien hecho", createdAt: "2025-05-23T14:00:00", updatedAt: "2025-05-23T14:30:00" },
    { id: "ORD-010", clientId: "CLI-006", clientName: "Miguel Torres", products: [
      { id: "PROD-001", name: "Tacos al Pastor", quantity: 3, unitPrice: 35, subtotal: 105 },
      { id: "PROD-006", name: "Refresco de Cola", quantity: 1, unitPrice: 18, subtotal: 18 }
    ], subtotal: 123, tax: 19.68, total: 142.68, status: "entregado", notes: "", createdAt: "2025-05-22T13:00:00", updatedAt: "2025-05-22T13:20:00" },
    { id: "ORD-011", clientId: "CLI-005", clientName: "Sofía Hernández", products: [
      { id: "PROD-002", name: "Tacos de Carnitas", quantity: 4, unitPrice: 32, subtotal: 128 },
      { id: "PROD-007", name: "Agua de Horchata", quantity: 2, unitPrice: 15, subtotal: 30 }
    ], subtotal: 158, tax: 25.28, total: 183.28, status: "pendiente", notes: "Entregar en domicilio", createdAt: "2025-05-22T11:00:00", updatedAt: "2025-05-22T11:00:00" },
    { id: "ORD-012", clientId: "CLI-002", clientName: "Juan Pérez", products: [
      { id: "PROD-003", name: "Tacos de Barbacoa", quantity: 6, unitPrice: 38, subtotal: 228 },
      { id: "PROD-005", name: "Guacamole", quantity: 2, unitPrice: 45, subtotal: 90 },
      { id: "PROD-008", name: "Flan Napolitano", quantity: 4, unitPrice: 25, subtotal: 100 }
    ], subtotal: 418, tax: 66.88, total: 484.88, status: "entregado", notes: "Pedido grande - cumpleaños", createdAt: "2025-05-21T19:00:00", updatedAt: "2025-05-21T19:45:00" }
  ],
  settings: {
    businessName: "Taquería El Pastorcito",
    email: "contacto@elpastorcito.com",
    phone: "55-1111-2222",
    taxRate: 16,
    autoTax: true,
    notifications: { email: true, sms: false }
  }
};

// ===================== DATA LAYER =====================
const Store = {
  _get(key, defaultVal) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : defaultVal;
    } catch { return defaultVal; }
  },
  _set(key, data) {
    try { localStorage.setItem(key, JSON.stringify(data)); } catch {}
  },

  init() {
    if (!localStorage.getItem('om_products')) {
      this._set('om_products', SEED.products);
      this._set('om_clients', SEED.clients);
      this._set('om_orders', SEED.orders);
      this._set('om_settings', SEED.settings);
    }
  },

  // Products
  getProducts() { return this._get('om_products', []); },
  getProductById(id) { return this.getProducts().find(p => p.id === id); },

  // Clients
  getClients() { return this._get('om_clients', []); },
  getClientById(id) { return this.getClients().find(c => c.id === id); },
  saveClient(client) {
    const clients = this.getClients();
    const idx = clients.findIndex(c => c.id === client.id);
    if (idx >= 0) clients[idx] = client; else clients.push(client);
    this._set('om_clients', clients);
  },

  // Orders
  getOrders() { return this._get('om_orders', []); },
  getOrderById(id) { return this.getOrders().find(o => o.id === id); },
  getOrdersByClientId(clientId) { return this.getOrders().filter(o => o.clientId === clientId); },
  getOrdersByStatus(status) { return this.getOrders().filter(o => o.status === status); },
  getTodayOrders() {
    const today = new Date().toISOString().slice(0, 10);
    return this.getOrders().filter(o => o.createdAt.slice(0, 10) === today);
  },

  saveOrder(order) {
    const orders = this.getOrders();
    const idx = orders.findIndex(o => o.id === order.id);
    if (idx >= 0) orders[idx] = order; else orders.unshift(order);
    this._set('om_orders', orders);
    this._recalcClientStats(order.clientId);
  },

  deleteOrder(id) {
    const order = this.getOrderById(id);
    const orders = this.getOrders().filter(o => o.id !== id);
    this._set('om_orders', orders);
    if (order) this._recalcClientStats(order.clientId);
  },

  updateOrderStatus(id, status) {
    const order = this.getOrderById(id);
    if (!order) return;
    order.status = status;
    order.updatedAt = new Date().toISOString();
    this.saveOrder(order);
  },

  _recalcClientStats(clientId) {
    const client = this.getClientById(clientId);
    if (!client) return;
    const clientOrders = this.getOrdersByClientId(clientId);
    client.totalOrders = clientOrders.length;
    client.totalSpent = clientOrders.reduce((sum, o) => sum + o.total, 0);
    client.lastOrderDate = clientOrders.length > 0
      ? clientOrders.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))[0].createdAt
      : null;
    this.saveClient(client);
  },

  // Settings
  getSettings() { return this._get('om_settings', SEED.settings); },
  saveSettings(settings) { this._set('om_settings', settings); },

  // Stats
  getDashboardStats() {
    const orders = this.getOrders();
    const today = new Date().toISOString().slice(0, 10);
    const todayOrders = orders.filter(o => o.createdAt.slice(0, 10) === today);
    const delivered = orders.filter(o => o.status === 'entregado');
    return {
      ordersToday: todayOrders.length,
      ordersTodayChange: 12,
      totalCollected: orders.reduce((s, o) => s + o.total, 0),
      deliveryRate: orders.length > 0 ? Math.round((delivered.length / orders.length) * 100) : 0,
      deliveryRateAvgDays: 2.4,
      pendingOrders: orders.filter(o => o.status === 'pendiente').length,
      inProcessOrders: orders.filter(o => o.status === 'en_proceso').length,
      deliveredOrders: delivered.length
    };
  }
};

// ===================== UTILITIES =====================
const currencyFmt = new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN' });
const dateFmt = new Intl.DateTimeFormat('es-MX', { dateStyle: 'medium' });
const dateTimeFmt = new Intl.DateTimeFormat('es-MX', { dateStyle: 'medium', timeStyle: 'short' });

function formatCurrency(amount) { return currencyFmt.format(amount); }
function formatDate(dateStr) { return dateFmt.format(new Date(dateStr)); }
function formatDateTime(dateStr) { return dateTimeFmt.format(new Date(dateStr)); }

function generateId(prefix) {
  const n = Date.now().toString(36).toUpperCase();
  const r = Math.random().toString(36).substring(2, 6).toUpperCase();
  return `${prefix}-${n}${r}`;
}

function statusLabel(status) {
  const labels = { pendiente: 'Pendiente', en_proceso: 'En Proceso', entregado: 'Entregado' };
  return labels[status] || status;
}

function tierLabel(tier) {
  return tier.charAt(0).toUpperCase() + tier.slice(1);
}

function calculateTotals(products, taxRate) {
  const subtotal = products.reduce((s, p) => s + (p.quantity * p.unitPrice), 0);
  const tax = subtotal * (taxRate / 100);
  return { subtotal, tax, total: subtotal + tax };
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

// ===================== TOAST =====================
function showToast(message, type = 'info') {
  const container = document.getElementById('toast-container');
  const toast = document.createElement('div');
  const icons = { success: 'check-circle', error: 'alert-circle', info: 'info' };
  const icon = icons[type] || icons.info;
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `<i data-lucide="${icon}" style="width:16px;height:16px;flex-shrink:0"></i>
    <span>${escapeHtml(message)}</span>
    <button class="toast-close" onclick="this.parentElement.remove()"><i data-lucide="x" style="width:14px;height:14px"></i></button>`;
  container.appendChild(toast);
  lucide.createIcons({ icons: {}, attrs: { class: ['lucide-icon'] } }, toast);
  setTimeout(() => { toast.style.opacity = '0'; toast.style.transition = 'opacity 0.3s'; setTimeout(() => toast.remove(), 300); }, 4000);
}

// ===================== MODAL =====================
function showModal(title, bodyHTML, footerHTML) {
  document.getElementById('modal-title').textContent = title;
  document.getElementById('modal-body').innerHTML = bodyHTML;
  const footer = document.getElementById('modal-footer');
  footer.innerHTML = footerHTML || '';
  document.getElementById('modal-overlay').classList.remove('hidden');
  document.getElementById('modal').classList.remove('hidden');
  lucide.createIcons();
}

function hideModal() {
  document.getElementById('modal-overlay').classList.add('hidden');
  document.getElementById('modal').classList.add('hidden');
}

document.getElementById('modal-overlay').addEventListener('click', hideModal);
document.querySelector('.modal-close').addEventListener('click', hideModal);

// ===================== CSV EXPORT =====================
function exportCSV(filename, headers, rows) {
  const csvContent = [
    headers.join(','),
    ...rows.map(r => r.map(cell => {
      const s = String(cell).replace(/"/g, '""');
      return s.includes(',') || s.includes('"') || s.includes('\n') ? `"${s}"` : s;
    }).join(','))
  ].join('\n');
  const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  URL.revokeObjectURL(a.href);
}

// ===================== BREADCRUMBS =====================
function setBreadcrumbs(items) {
  const el = document.getElementById('breadcrumbs');
  el.innerHTML = items.map((item, i) => {
    if (i < items.length - 1 && item.href) {
      return `<a href="${item.href}" class="breadcrumb-item">${escapeHtml(item.label)}</a>`;
    }
    return `<span class="breadcrumb-item">${escapeHtml(item.label)}</span>`;
  }).join('');
}

// ===================== THEME =====================
function initTheme() {
  const saved = localStorage.getItem('om_theme') || 'light';
  document.documentElement.setAttribute('data-theme', saved);
  updateThemeIcon(saved);
}

function toggleTheme() {
  const current = document.documentElement.getAttribute('data-theme');
  const next = current === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', next);
  localStorage.setItem('om_theme', next);
  updateThemeIcon(next);
}

function updateThemeIcon(theme) {
  const icon = document.querySelector('#theme-toggle i');
  if (icon) {
    icon.setAttribute('data-lucide', theme === 'dark' ? 'sun' : 'moon');
    lucide.createIcons();
  }
}

// ===================== SIDEBAR =====================
function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('open');
}

document.getElementById('sidebar-toggle').addEventListener('click', toggleSidebar);

// Close sidebar on mobile when clicking a nav link
document.getElementById('sidebar-nav').addEventListener('click', (e) => {
  if (window.innerWidth <= 768) {
    document.getElementById('sidebar').classList.remove('open');
  }
});

// ===================== ACTIVE NAV =====================
function updateActiveNav(route) {
  document.querySelectorAll('.nav-item').forEach(el => {
    el.classList.toggle('active', el.dataset.route === route);
  });
}

// ===================== ROUTER =====================
function getRouteParams(hash) {
  const path = hash.replace(/^#/, '') || '/';

  // Static routes
  const staticRoutes = {
    '/': 'dashboard',
    '/pedidos': 'orders',
    '/pedidos/nuevo': 'newOrder',
    '/clientes': 'clients',
    '/reportes': 'reports',
    '/ajustes': 'settings'
  };
  if (staticRoutes[path]) return { page: staticRoutes[path], params: {} };

  // Dynamic routes: /pedidos/:id
  const ordersMatch = path.match(/^\/pedidos\/(.+)$/);
  if (ordersMatch) return { page: 'orderDetail', params: { id: ordersMatch[1] } };

  // Dynamic routes: /clientes/:id
  const clientsMatch = path.match(/^\/clientes\/(.+)$/);
  if (clientsMatch) return { page: 'clientDetail', params: { id: clientsMatch[1] } };

  return { page: 'notFound', params: {} };
}

function navigate(hash) {
  window.location.hash = hash;
}

function handleRoute() {
  const { page, params } = getRouteParams(window.location.hash || '#/');
  const content = document.getElementById('content');
  content.innerHTML = '<div class="page-loader"><div class="spinner"></div></div>';

  let route = '/';
  switch (page) {
    case 'dashboard': route = '/'; renderDashboard(); break;
    case 'orders': route = '/pedidos'; renderOrders(); break;
    case 'newOrder': route = '/pedidos/nuevo'; renderNewOrder(); break;
    case 'orderDetail': route = '/pedidos'; renderOrderDetail(params.id); break;
    case 'clients': route = '/clientes'; renderClients(); break;
    case 'clientDetail': route = '/clientes'; renderClientDetail(params.id); break;
    case 'reports': route = '/reportes'; renderReports(); break;
    case 'settings': route = '/ajustes'; renderSettings(); break;
    default: renderNotFound(); break;
  }
  updateActiveNav(route);
}

window.addEventListener('hashchange', handleRoute);

// ===================== PAGE: DASHBOARD =====================
function renderDashboard() {
  setBreadcrumbs([{ label: 'Dashboard' }]);

  const stats = Store.getDashboardStats();
  const todayOrders = Store.getTodayOrders();
  const products = Store.getProducts();

  const html = `
    <div class="section-header">
      <h1>Dashboard</h1>
    </div>
    <div class="stats-grid">
      <div class="stat-card">
        <div class="stat-label">Pedidos Hoy</div>
        <div class="stat-value">${stats.ordersToday}</div>
        <div class="stat-change up">+${stats.ordersTodayChange}% vs ayer</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Total Cobrado</div>
        <div class="stat-value">${formatCurrency(stats.totalCollected)}</div>
        <div class="stat-subtitle">Histórico total</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Tasa de Entrega</div>
        <div class="stat-value">${stats.deliveryRate}%</div>
        <div class="stat-subtitle">Promedio ${stats.deliveryRateAvgDays} días</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Pendientes / En Proceso</div>
        <div class="stat-value">${stats.pendingOrders} / ${stats.inProcessOrders}</div>
        <div class="stat-subtitle">${stats.deliveredOrders} entregados</div>
      </div>
    </div>
    <div class="card">
      <div class="card-header">
        <div class="card-title">Operaciones de Hoy</div>
      </div>
      <div class="card-body">
        ${todayOrders.length === 0 ? '<div class="empty-state"><i data-lucide="shopping-cart" style="width:48px;height:48px"></i><h3>Sin pedidos hoy</h3><p>Aún no hay pedidos registrados el día de hoy.</p></div>' : `
        <div class="table-container">
          <table>
            <thead>
              <tr>
                <th>Pedido</th><th>Cliente</th><th>Productos</th><th>Total</th><th>Estado</th><th>Hora</th>
              </tr>
            </thead>
            <tbody>
              ${todayOrders.map(o => `
                <tr style="cursor:pointer" onclick="navigate('#/pedidos/${o.id}')">
                  <td class="font-mono">${o.id}</td>
                  <td>${escapeHtml(o.clientName)}</td>
                  <td>${o.products.length} prod.</td>
                  <td class="font-mono">${formatCurrency(o.total)}</td>
                  <td><span class="badge badge-${o.status}">${statusLabel(o.status)}</span></td>
                  <td>${new Date(o.createdAt).toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' })}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>`}
      </div>
    </div>`;

  document.getElementById('content').innerHTML = html;
  lucide.createIcons();
}

// ===================== PAGE: ORDERS =====================
let ordersState = { status: 'todos', search: '', page: 1, pageSize: 10 };

function renderOrders() {
  setBreadcrumbs([{ label: 'Pedidos', href: '#/pedidos' }]);

  let orders = Store.getOrders();
  if (ordersState.status !== 'todos') {
    orders = orders.filter(o => o.status === ordersState.status);
  }
  if (ordersState.search) {
    const s = ordersState.search.toLowerCase();
    orders = orders.filter(o => o.id.toLowerCase().includes(s) || o.clientName.toLowerCase().includes(s));
  }
  orders.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  const totalItems = orders.length;
  const totalPages = Math.max(1, Math.ceil(totalItems / ordersState.pageSize));
  if (ordersState.page > totalPages) ordersState.page = totalPages;
  const start = (ordersState.page - 1) * ordersState.pageSize;
  const pageOrders = orders.slice(start, start + ordersState.pageSize);

  const html = `
    <div class="section-header">
      <h1>Pedidos</h1>
      <div style="display:flex;gap:8px">
        <div class="search-wrapper">
          <i data-lucide="search"></i>
          <input type="text" class="form-input" id="orders-search" placeholder="Buscar pedido..." value="${escapeHtml(ordersState.search)}">
        </div>
        <button class="btn btn-secondary btn-sm" onclick="exportOrdersCSV()">
          <i data-lucide="download" style="width:14px;height:14px"></i> CSV
        </button>
        <a href="#/pedidos/nuevo" class="btn btn-primary">
          <i data-lucide="plus" style="width:16px;height:16px"></i> Nuevo Pedido
        </a>
      </div>
    </div>
    <div class="filter-bar">
      <div class="filter-btn-group">
        ${['todos','pendiente','en_proceso','entregado'].map(s => `
          <button class="filter-btn ${ordersState.status === s ? 'active' : ''}" onclick="filterOrders('${s}')">${s === 'todos' ? 'Todos' : statusLabel(s)}</button>
        `).join('')}
      </div>
    </div>
    <div class="card">
      <div class="card-body">
        ${pageOrders.length === 0 ? '<div class="empty-state"><i data-lucide="shopping-cart" style="width:48px;height:48px"></i><h3>Sin resultados</h3><p>No se encontraron pedidos con los filtros actuales.</p></div>' : `
        <div class="table-container">
          <table>
            <thead><tr>
              <th>Pedido</th><th>Cliente</th><th>Productos</th><th>Total</th><th>Estado</th><th>Fecha</th><th>Acción</th>
            </tr></thead>
            <tbody>
              ${pageOrders.map(o => `
                <tr>
                  <td class="font-mono">${o.id}</td>
                  <td>${escapeHtml(o.clientName)}</td>
                  <td>${o.products.length} prod.</td>
                  <td class="font-mono">${formatCurrency(o.total)}</td>
                  <td>
                    <select class="status-select ${o.status}" onchange="updateOrderStatus('${o.id}', this.value)">
                      <option value="pendiente" ${o.status==='pendiente'?'selected':''}>Pendiente</option>
                      <option value="en_proceso" ${o.status==='en_proceso'?'selected':''}>En Proceso</option>
                      <option value="entregado" ${o.status==='entregado'?'selected':''}>Entregado</option>
                    </select>
                  </td>
                  <td>${formatDate(o.createdAt)}</td>
                  <td>
                    <button class="btn btn-ghost btn-sm" onclick="navigate('#/pedidos/${o.id}')"><i data-lucide="eye" style="width:14px;height:14px"></i></button>
                    <button class="btn btn-ghost btn-sm" onclick="confirmDeleteOrder('${o.id}')"><i data-lucide="trash-2" style="width:14px;height:14px;color:var(--danger)"></i></button>
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
        ${totalPages > 1 ? `
        <div class="pagination">
          <button class="page-btn" ${ordersState.page <= 1 ? 'disabled' : ''} onclick="goToPage(${ordersState.page - 1})">Anterior</button>
          ${Array.from({length: totalPages}, (_, i) => i + 1).map(p =>
            `<button class="page-btn ${p === ordersState.page ? 'active' : ''}" onclick="goToPage(${p})">${p}</button>`
          ).join('')}
          <button class="page-btn" ${ordersState.page >= totalPages ? 'disabled' : ''} onclick="goToPage(${ordersState.page + 1})">Siguiente</button>
        </div>` : ''}`}
      </div>
    </div>`;

  document.getElementById('content').innerHTML = html;
  lucide.createIcons();

  document.getElementById('orders-search').addEventListener('input', (e) => {
    ordersState.search = e.target.value;
    ordersState.page = 1;
    renderOrders();
  });
}

// Event handlers for orders page (declared globally for onclick)
function filterOrders(status) {
  ordersState.status = status;
  ordersState.page = 1;
  renderOrders();
}
function goToPage(page) {
  ordersState.page = page;
  renderOrders();
}
function updateOrderStatus(id, status) {
  Store.updateOrderStatus(id, status);
  showToast(`Pedido ${id} actualizado a "${statusLabel(status)}"`, 'success');
  renderOrders();
}
function confirmDeleteOrder(id) {
  const order = Store.getOrderById(id);
  showModal('Eliminar Pedido',
    `<p>¿Estás seguro de que deseas eliminar el pedido <strong>${escapeHtml(id)}</strong> de ${escapeHtml(order ? order.clientName : '')}?</p>
     <p style="color:var(--danger);font-size:0.85rem;margin-top:8px">Esta acción no se puede deshacer.</p>`,
    `<button class="btn btn-secondary" onclick="hideModal()">Cancelar</button>
     <button class="btn btn-danger" onclick="deleteOrder('${id}')">Eliminar</button>`
  );
  lucide.createIcons();
}
function deleteOrder(id) {
  Store.deleteOrder(id);
  hideModal();
  showToast(`Pedido ${id} eliminado`, 'success');
  renderOrders();
}
function exportOrdersCSV() {
  let orders = Store.getOrders();
  if (ordersState.status !== 'todos') orders = orders.filter(o => o.status === ordersState.status);
  if (ordersState.search) {
    const s = ordersState.search.toLowerCase();
    orders = orders.filter(o => o.id.toLowerCase().includes(s) || o.clientName.toLowerCase().includes(s));
  }
  exportCSV('pedidos.csv',
    ['ID', 'Cliente', 'Productos', 'Subtotal', 'IVA', 'Total', 'Estado', 'Fecha'],
    orders.map(o => [o.id, o.clientName, o.products.map(p => `${p.name}x${p.quantity}`).join(' / '), o.subtotal.toFixed(2), o.tax.toFixed(2), o.total.toFixed(2), statusLabel(o.status), formatDateTime(o.createdAt)])
  );
  showToast('CSV exportado correctamente', 'success');
}

// ===================== PAGE: NEW ORDER =====================
function renderNewOrder() {
  setBreadcrumbs([{ label: 'Pedidos', href: '#/pedidos' }, { label: 'Nuevo Pedido' }]);

  const clients = Store.getClients();
  const products = Store.getProducts();
  const settings = Store.getSettings();
  const taxRate = settings.autoTax ? settings.taxRate : 0;

  const html = `
    <div class="section-header">
      <h1>Nuevo Pedido</h1>
    </div>
    <form id="new-order-form">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:24px">
        <div class="card">
          <div class="card-header"><div class="card-title">Información del Cliente</div></div>
          <div class="card-body">
            <div class="form-group">
              <label class="form-label">Cliente *</label>
              <select class="form-select" id="order-client" required>
                <option value="">Seleccionar cliente...</option>
                ${clients.map(c => `<option value="${c.id}">${escapeHtml(c.name)}</option>`).join('')}
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">Notas</label>
              <textarea class="form-textarea" id="order-notes" placeholder="Notas adicionales..."></textarea>
            </div>
          </div>
        </div>
        <div class="card">
          <div class="card-header"><div class="card-title">Resumen</div></div>
          <div class="card-body">
            <div class="order-summary">
              <div class="order-summary-row"><span>Subtotal</span><span id="summary-subtotal">$0.00</span></div>
              <div class="order-summary-row"><span>IVA (${taxRate}%)</span><span id="summary-tax">$0.00</span></div>
              <div class="order-summary-row total"><span>Total</span><span id="summary-total">$0.00</span></div>
            </div>
          </div>
        </div>
      </div>
      <div class="card" style="margin-top:24px">
        <div class="card-header">
          <div class="card-title">Productos</div>
          <button type="button" class="btn btn-secondary btn-sm" onclick="addProductLine()">
            <i data-lucide="plus" style="width:14px;height:14px"></i> Agregar Producto
          </button>
        </div>
        <div class="card-body">
          <div id="product-lines">
            ${renderProductLine(products, 0, settings.taxRate)}
          </div>
        </div>
        <div class="card-footer">
          <div style="display:flex;justify-content:flex-end;gap:8px">
            <a href="#/pedidos" class="btn btn-secondary">Cancelar</a>
            <button type="submit" class="btn btn-primary">
              <i data-lucide="save" style="width:16px;height:16px"></i> Guardar Pedido
            </button>
          </div>
        </div>
      </div>
    </form>`;

  document.getElementById('content').innerHTML = html;
  lucide.createIcons();

  // Initialize first product line event
  initProductLineEvents(0, taxRate);

  document.getElementById('new-order-form').addEventListener('submit', handleNewOrderSubmit);
}

let productLineCount = 1;

function renderProductLine(products, index, taxRate) {
  return `
    <div class="product-line" data-line="${index}">
      <div class="form-group">
        <label class="form-label">Producto</label>
        <select class="form-select form-input-sm product-select" data-line="${index}">
          <option value="">Seleccionar...</option>
          ${products.map(p => `<option value="${p.id}" data-price="${p.price}">${escapeHtml(p.name)} - ${formatCurrency(p.price)}</option>`).join('')}
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Cantidad</label>
        <input type="number" class="form-input form-input-sm product-qty" data-line="${index}" value="1" min="1">
      </div>
      <div class="form-group">
        <label class="form-label">Precio</label>
        <input type="number" class="form-input form-input-sm product-price" data-line="${index}" value="0" min="0" step="0.01">
      </div>
      <div class="form-group">
        <label class="form-label">Subtotal</label>
        <div class="product-subtotal" data-line="${index}" style="padding:6px 0;font-weight:600">$0.00</div>
      </div>
      ${index > 0 ? `<button type="button" class="btn btn-ghost btn-sm" onclick="removeProductLine(${index})" style="margin-bottom:0;align-self:end"><i data-lucide="x" style="width:16px;height:16px;color:var(--danger)"></i></button>` : '<div style="width:36px"></div>'}
    </div>`;
}

function initProductLineEvents(index, taxRate) {
  const line = document.querySelector(`.product-line[data-line="${index}"]`);
  if (!line) return;

  const select = line.querySelector('.product-select');
  const qty = line.querySelector('.product-qty');
  const price = line.querySelector('.product-price');

  const updateLine = () => {
    const q = parseInt(qty.value) || 0;
    const p = parseFloat(price.value) || 0;
    const subtotal = q * p;
    line.querySelector('.product-subtotal').textContent = formatCurrency(subtotal);
    updateSummary(taxRate);
  };

  if (select) {
    select.addEventListener('change', () => {
      const opt = select.options[select.selectedIndex];
      if (opt && opt.dataset.price) {
        price.value = opt.dataset.price;
      }
      updateLine();
    });
  }
  if (qty) qty.addEventListener('input', updateLine);
  if (price) price.addEventListener('input', updateLine);
}

function addProductLine() {
  const products = Store.getProducts();
  const settings = Store.getSettings();
  const container = document.getElementById('product-lines');
  const idx = productLineCount;
  container.insertAdjacentHTML('beforeend', renderProductLine(products, idx, settings.taxRate));
  initProductLineEvents(idx, settings.taxRate);
  productLineCount++;
  lucide.createIcons();
}

function removeProductLine(index) {
  const line = document.querySelector(`.product-line[data-line="${index}"]`);
  if (line) line.remove();
  const settings = Store.getSettings();
  updateSummary(settings.autoTax ? settings.taxRate : 0);
}

function updateSummary(taxRate) {
  let subtotal = 0;
  document.querySelectorAll('.product-line').forEach(line => {
    const qty = parseInt(line.querySelector('.product-qty').value) || 0;
    const price = parseFloat(line.querySelector('.product-price').value) || 0;
    subtotal += qty * price;
  });
  const tax = subtotal * (taxRate / 100);
  const total = subtotal + tax;
  document.getElementById('summary-subtotal').textContent = formatCurrency(subtotal);
  document.getElementById('summary-tax').textContent = formatCurrency(tax);
  document.getElementById('summary-total').textContent = formatCurrency(total);
  return { subtotal, tax, total };
}

function handleNewOrderSubmit(e) {
  e.preventDefault();
  const clientSelect = document.getElementById('order-client');
  const clientId = clientSelect.value;
  if (!clientId) { showToast('Selecciona un cliente', 'error'); return; }

  const clients = Store.getClients();
  const client = clients.find(c => c.id === clientId);
  if (!client) { showToast('Cliente no encontrado', 'error'); return; }

  const setting = Store.getSettings();
  const taxRate = setting.autoTax ? setting.taxRate : 0;

  const products = [];
  document.querySelectorAll('.product-line').forEach(line => {
    const select = line.querySelector('.product-select');
    const qty = parseInt(line.querySelector('.product-qty').value) || 0;
    const price = parseFloat(line.querySelector('.product-price').value) || 0;
    if (select && select.value && qty > 0) {
      const opt = select.options[select.selectedIndex];
      products.push({
        id: select.value,
        name: opt.textContent.split(' - ')[0].trim(),
        quantity: qty,
        unitPrice: price,
        subtotal: qty * price
      });
    }
  });

  if (products.length === 0) { showToast('Agrega al menos un producto', 'error'); return; }

  const { subtotal, tax, total } = calculateTotals(products, taxRate);
  const now = new Date().toISOString();

  const order = {
    id: generateId('ORD'),
    clientId,
    clientName: client.name,
    products,
    subtotal,
    tax,
    total,
    status: 'pendiente',
    notes: document.getElementById('order-notes').value.trim(),
    createdAt: now,
    updatedAt: now
  };

  Store.saveOrder(order);
  showToast(`Pedido ${order.id} creado exitosamente`, 'success');
  navigate('#/pedidos/' + order.id);
}

// ===================== PAGE: ORDER DETAIL =====================
function renderOrderDetail(id) {
  const order = Store.getOrderById(id);
  if (!order) {
    setBreadcrumbs([{ label: 'Pedidos', href: '#/pedidos' }, { label: 'No encontrado' }]);
    document.getElementById('content').innerHTML = `
      <div class="empty-state">
        <i data-lucide="file-x" style="width:48px;height:48px"></i>
        <h3>Pedido no encontrado</h3>
        <p>El pedido ${escapeHtml(id)} no existe.</p>
        <a href="#/pedidos" class="btn btn-primary" style="margin-top:16px">Volver a Pedidos</a>
      </div>`;
    lucide.createIcons();
    return;
  }

  setBreadcrumbs([{ label: 'Pedidos', href: '#/pedidos' }, { label: order.id }]);

  const client = Store.getClientById(order.clientId);

  const html = `
    <div class="section-header">
      <h1>Pedido ${order.id}</h1>
      <div style="display:flex;gap:8px">
        <span class="badge badge-${order.status}" style="font-size:0.9rem;padding:4px 12px">${statusLabel(order.status)}</span>
        <select class="status-select ${order.status}" onchange="updateOrderDetailStatus('${order.id}', this.value)" style="font-size:0.85rem;padding:6px 12px">
          <option value="pendiente" ${order.status==='pendiente'?'selected':''}>Pendiente</option>
          <option value="en_proceso" ${order.status==='en_proceso'?'selected':''}>En Proceso</option>
          <option value="entregado" ${order.status==='entregado'?'selected':''}>Entregado</option>
        </select>
        <a href="#/pedidos" class="btn btn-secondary btn-sm"><i data-lucide="arrow-left" style="width:14px;height:14px"></i> Volver</a>
        <button class="btn btn-danger btn-sm" onclick="confirmDeleteOrder('${order.id}')"><i data-lucide="trash-2" style="width:14px;height:14px"></i> Eliminar</button>
      </div>
    </div>
    <div class="detail-grid">
      <div class="card">
        <div class="card-header"><div class="card-title">Cliente</div></div>
        <div class="card-body">
          <div class="detail-row"><span class="detail-label">Nombre</span><span class="detail-value">${escapeHtml(order.clientName)}</span></div>
          ${client ? `
          <div class="detail-row"><span class="detail-label">Email</span><span class="detail-value">${escapeHtml(client.email)}</span></div>
          <div class="detail-row"><span class="detail-label">Teléfono</span><span class="detail-value">${escapeHtml(client.phone)}</span></div>
          <div class="detail-row"><span class="detail-label">Ubicación</span><span class="detail-value">${escapeHtml(client.location)}</span></div>
          ` : ''}
        </div>
      </div>
      <div class="card">
        <div class="card-header"><div class="card-title">Resumen</div></div>
        <div class="card-body">
          <div class="detail-row"><span class="detail-label">Creado</span><span class="detail-value">${formatDateTime(order.createdAt)}</span></div>
          <div class="detail-row"><span class="detail-label">Actualizado</span><span class="detail-value">${formatDateTime(order.updatedAt)}</span></div>
          ${order.notes ? `<div class="detail-row"><span class="detail-label">Notas</span><span class="detail-value">${escapeHtml(order.notes)}</span></div>` : ''}
        </div>
      </div>
    </div>
    <div class="card">
      <div class="card-header"><div class="card-title">Productos</div></div>
      <div class="card-body">
        <div class="table-container">
          <table>
            <thead><tr>
              <th>Producto</th><th class="text-right">Cantidad</th><th class="text-right">Precio Unit.</th><th class="text-right">Subtotal</th>
            </tr></thead>
            <tbody>
              ${order.products.map(p => `
                <tr>
                  <td>${escapeHtml(p.name)}</td>
                  <td class="text-right">${p.quantity}</td>
                  <td class="text-right font-mono">${formatCurrency(p.unitPrice)}</td>
                  <td class="text-right font-mono">${formatCurrency(p.subtotal)}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      </div>
      <div class="card-footer">
        <div class="order-summary" style="max-width:300px;margin-left:auto">
          <div class="order-summary-row"><span>Subtotal</span><span class="font-mono">${formatCurrency(order.subtotal)}</span></div>
          <div class="order-summary-row"><span>IVA</span><span class="font-mono">${formatCurrency(order.tax)}</span></div>
          <div class="order-summary-row total"><span>Total</span><span class="font-mono">${formatCurrency(order.total)}</span></div>
        </div>
      </div>
    </div>`;

  document.getElementById('content').innerHTML = html;
  lucide.createIcons();
}

function updateOrderDetailStatus(id, status) {
  Store.updateOrderStatus(id, status);
  showToast(`Estado actualizado a "${statusLabel(status)}"`, 'success');
  renderOrderDetail(id);
}

// ===================== PAGE: CLIENTS =====================
let clientsSearch = '';

function renderClients() {
  setBreadcrumbs([{ label: 'Clientes' }]);

  let clients = Store.getClients();
  if (clientsSearch) {
    const s = clientsSearch.toLowerCase();
    clients = clients.filter(c => c.name.toLowerCase().includes(s) || c.email.toLowerCase().includes(s));
  }

  const html = `
    <div class="section-header">
      <h1>Clientes</h1>
      <div style="display:flex;gap:8px">
        <div class="search-wrapper">
          <i data-lucide="search"></i>
          <input type="text" class="form-input" id="clients-search" placeholder="Buscar cliente..." value="${escapeHtml(clientsSearch)}">
        </div>
        <button class="btn btn-secondary btn-sm" onclick="exportClientsCSV()">
          <i data-lucide="download" style="width:14px;height:14px"></i> CSV
        </button>
      </div>
    </div>
    ${clients.length === 0 ? '<div class="empty-state"><i data-lucide="users" style="width:48px;height:48px"></i><h3>Sin resultados</h3><p>No se encontraron clientes.</p></div>' : `
    <div class="client-grid">
      ${clients.map(c => `
        <div class="client-card" onclick="navigate('#/clientes/${c.id}')">
          <div class="client-card-top">
            <div class="client-avatar">${c.name.charAt(0).toUpperCase()}</div>
            <div class="client-info">
              <div class="client-name">${escapeHtml(c.name)}</div>
              <div class="client-contact">${escapeHtml(c.email)}</div>
              <div class="client-contact">${escapeHtml(c.phone)}</div>
            </div>
            <span class="badge badge-${c.tier}">${tierLabel(c.tier)}</span>
          </div>
          <div class="client-card-stats">
            <span><i data-lucide="shopping-bag" style="width:14px;height:14px"></i> ${c.totalOrders} pedidos</span>
            <span><i data-lucide="tag" style="width:14px;height:14px"></i> ${formatCurrency(c.totalSpent)}</span>
          </div>
        </div>
      `).join('')}
    </div>`}`;

  document.getElementById('content').innerHTML = html;
  lucide.createIcons();

  document.getElementById('clients-search').addEventListener('input', (e) => {
    clientsSearch = e.target.value;
    renderClients();
  });
}

function exportClientsCSV() {
  let clients = Store.getClients();
  if (clientsSearch) {
    const s = clientsSearch.toLowerCase();
    clients = clients.filter(c => c.name.toLowerCase().includes(s) || c.email.toLowerCase().includes(s));
  }
  exportCSV('clientes.csv',
    ['ID', 'Nombre', 'Email', 'Teléfono', 'Ubicación', 'Tier', 'Pedidos', 'Total Gastado', 'Miembro Desde'],
    clients.map(c => [c.id, c.name, c.email, c.phone, c.location, tierLabel(c.tier), c.totalOrders, formatCurrency(c.totalSpent), formatDate(c.memberSince)])
  );
  showToast('CSV exportado correctamente', 'success');
}

// ===================== PAGE: CLIENT DETAIL =====================
function renderClientDetail(id) {
  const client = Store.getClientById(id);
  if (!client) {
    setBreadcrumbs([{ label: 'Clientes', href: '#/clientes' }, { label: 'No encontrado' }]);
    document.getElementById('content').innerHTML = `
      <div class="empty-state">
        <i data-lucide="user-x" style="width:48px;height:48px"></i>
        <h3>Cliente no encontrado</h3>
        <p>El cliente solicitado no existe.</p>
        <a href="#/clientes" class="btn btn-primary" style="margin-top:16px">Volver a Clientes</a>
      </div>`;
    lucide.createIcons();
    return;
  }

  setBreadcrumbs([{ label: 'Clientes', href: '#/clientes' }, { label: client.name }]);

  const orders = Store.getOrdersByClientId(id);
  const ordersTotal = orders.reduce((s, o) => s + o.total, 0);

  const html = `
    <div class="section-header">
      <h1>${escapeHtml(client.name)}</h1>
      <a href="#/clientes" class="btn btn-secondary btn-sm"><i data-lucide="arrow-left" style="width:14px;height:14px"></i> Volver</a>
    </div>
    <div class="stats-grid">
      <div class="stat-card">
        <div class="stat-label">Total Gastado</div>
        <div class="stat-value">${formatCurrency(client.totalSpent)}</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Pedidos Realizados</div>
        <div class="stat-value">${client.totalOrders}</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Última Compra</div>
        <div class="stat-value" style="font-size:1rem">${client.lastOrderDate ? formatDate(client.lastOrderDate) : 'N/A'}</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Categoría</div>
        <div class="stat-value" style="font-size:1rem"><span class="badge badge-${client.tier}" style="font-size:0.9rem;padding:4px 12px">${tierLabel(client.tier)}</span></div>
      </div>
    </div>
    <div class="detail-grid">
      <div class="card">
        <div class="card-header"><div class="card-title">Información de Contacto</div></div>
        <div class="card-body">
          <div class="detail-row"><span class="detail-label">Email</span><span class="detail-value">${escapeHtml(client.email)}</span></div>
          <div class="detail-row"><span class="detail-label">Teléfono</span><span class="detail-value">${escapeHtml(client.phone)}</span></div>
          <div class="detail-row"><span class="detail-label">Ubicación</span><span class="detail-value">${escapeHtml(client.location)}</span></div>
          <div class="detail-row"><span class="detail-label">Miembro Desde</span><span class="detail-value">${formatDate(client.memberSince)}</span></div>
        </div>
      </div>
    </div>
    <div class="card">
      <div class="card-header"><div class="card-title">Historial de Pedidos</div></div>
      <div class="card-body">
        ${orders.length === 0 ? '<div class="empty-state"><i data-lucide="shopping-cart" style="width:48px;height:48px"></i><h3>Sin pedidos</h3><p>Este cliente aún no ha realizado pedidos.</p></div>' : `
        <div class="table-container">
          <table>
            <thead><tr>
              <th>Pedido</th><th>Productos</th><th>Total</th><th>Estado</th><th>Fecha</th><th></th>
            </tr></thead>
            <tbody>
              ${orders.sort((a,b) => new Date(b.createdAt) - new Date(a.createdAt)).map(o => `
                <tr>
                  <td class="font-mono">${o.id}</td>
                  <td>${o.products.length} prod.</td>
                  <td class="font-mono">${formatCurrency(o.total)}</td>
                  <td><span class="badge badge-${o.status}">${statusLabel(o.status)}</span></td>
                  <td>${formatDate(o.createdAt)}</td>
                  <td><button class="btn btn-ghost btn-sm" onclick="navigate('#/pedidos/${o.id}')"><i data-lucide="eye" style="width:14px;height:14px"></i></button></td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>`}
      </div>
    </div>`;

  document.getElementById('content').innerHTML = html;
  lucide.createIcons();
}

// ===================== PAGE: REPORTS =====================
function renderReports() {
  setBreadcrumbs([{ label: 'Reportes' }]);
  document.getElementById('content').innerHTML = `
    <div class="section-header"><h1>Reportes</h1></div>
    <div class="card">
      <div class="card-body">
        <div class="empty-state">
          <i data-lucide="bar-chart-3" style="width:64px;height:64px;color:var(--accent)"></i>
          <h3>Próximamente</h3>
          <p>Los reportes y análisis detallados estarán disponibles pronto.</p>
        </div>
      </div>
    </div>`;
  lucide.createIcons();
}

// ===================== PAGE: NOT FOUND =====================
function renderNotFound() {
  document.getElementById('content').innerHTML = `
    <div class="empty-state">
      <i data-lucide="file-x" style="width:64px;height:64px"></i>
      <h3>Página no encontrada</h3>
      <p>La página solicitada no existe.</p>
      <a href="#/" class="btn btn-primary" style="margin-top:16px">Ir al Dashboard</a>
    </div>`;
  lucide.createIcons();
}

// ===================== PAGE: SETTINGS =====================
function renderSettings() {
  setBreadcrumbs([{ label: 'Ajustes' }]);
  const s = Store.getSettings();

  const html = `
    <div class="section-header"><h1>Ajustes</h1></div>
    <form id="settings-form">
      <div class="card">
        <div class="card-header"><div class="card-title">Configuración del Negocio</div></div>
        <div class="card-body">
          <div class="settings-section">
            <h3>Información General</h3>
            <div class="form-group">
              <label class="form-label">Nombre del Negocio</label>
              <input type="text" class="form-input" id="set-business-name" value="${escapeHtml(s.businessName)}">
            </div>
            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Email de Contacto</label>
                <input type="email" class="form-input" id="set-email" value="${escapeHtml(s.email)}">
              </div>
              <div class="form-group">
                <label class="form-label">Teléfono</label>
                <input type="text" class="form-input" id="set-phone" value="${escapeHtml(s.phone)}">
              </div>
            </div>
          </div>
          <div class="settings-section">
            <h3>Impuestos</h3>
            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Tasa de IVA (%)</label>
                <input type="number" class="form-input" id="set-tax-rate" value="${s.taxRate}" min="0" max="100" step="0.1">
              </div>
              <div class="form-group">
                <label class="form-label">&nbsp;</label>
                <label class="toggle">
                  <input type="checkbox" id="set-auto-tax" ${s.autoTax ? 'checked' : ''}>
                  <span class="toggle-slider"></span>
                  <span>Calcular IVA automáticamente</span>
                </label>
              </div>
            </div>
          </div>
          <div class="settings-section">
            <h3>Notificaciones</h3>
            <div style="display:flex;flex-direction:column;gap:12px">
              <label class="toggle">
                <input type="checkbox" id="set-notif-email" ${s.notifications.email ? 'checked' : ''}>
                <span class="toggle-slider"></span>
                <span>Notificaciones por email</span>
              </label>
              <label class="toggle">
                <input type="checkbox" id="set-notif-sms" ${s.notifications.sms ? 'checked' : ''}>
                <span class="toggle-slider"></span>
                <span>Notificaciones por SMS</span>
              </label>
            </div>
          </div>
        </div>
        <div class="card-footer">
          <div class="form-actions" style="border:none;margin:0;padding:0">
            <button type="submit" class="btn btn-primary"><i data-lucide="save" style="width:16px;height:16px"></i> Guardar Cambios</button>
          </div>
        </div>
      </div>
    </form>`;

  document.getElementById('content').innerHTML = html;
  lucide.createIcons();

  document.getElementById('settings-form').addEventListener('submit', handleSettingsSubmit);
}

function handleSettingsSubmit(e) {
  e.preventDefault();
  const settings = {
    businessName: document.getElementById('set-business-name').value.trim(),
    email: document.getElementById('set-email').value.trim(),
    phone: document.getElementById('set-phone').value.trim(),
    taxRate: parseFloat(document.getElementById('set-tax-rate').value) || 0,
    autoTax: document.getElementById('set-auto-tax').checked,
    notifications: {
      email: document.getElementById('set-notif-email').checked,
      sms: document.getElementById('set-notif-sms').checked
    }
  };
  Store.saveSettings(settings);
  showToast('Configuración guardada exitosamente', 'success');
}

// ===================== INIT =====================
document.addEventListener('DOMContentLoaded', () => {
  Store.init();
  initTheme();
  document.getElementById('theme-toggle').addEventListener('click', toggleTheme);

  if (!window.location.hash || window.location.hash === '#') {
    window.location.hash = '#/';
  }
  handleRoute();
});
