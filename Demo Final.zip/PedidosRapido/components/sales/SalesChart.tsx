"use client"

import { useState, useMemo } from "react"
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ComposedChart } from "recharts"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import type { Order } from "@/lib/types"
import {
  aggregateSalesByDay,
  aggregateSalesByWeek,
  aggregateSalesByMonth,
  calculateSalesStats,
  formatCurrency,
  type DailySalesData,
  type WeeklySalesData,
  type MonthlySalesData,
} from "@/lib/sales-aggregation"
import { TrendingUp, DollarSign, ShoppingCart } from "lucide-react"

interface SalesChartProps {
  orders: Order[]
}

export function SalesChart({ orders }: SalesChartProps) {
  const [period, setPeriod] = useState<"day" | "week" | "month">("week")

  const { data, stats } = useMemo(() => {
    let chartData: DailySalesData[] | WeeklySalesData[] | MonthlySalesData[] = []
    
    switch (period) {
      case "day":
        chartData = aggregateSalesByDay(orders, 30)
        break
      case "week":
        chartData = aggregateSalesByWeek(orders, 12)
        break
      case "month":
        chartData = aggregateSalesByMonth(orders, 12)
        break
    }
    
    const stats = calculateSalesStats(chartData)
    return { data: chartData, stats }
  }, [orders, period])

  const chartConfig = {
    day: {
      xAxisKey: "date" as const,
      label: "Fecha",
    },
    week: {
      xAxisKey: "week" as const,
      label: "Semana",
    },
    month: {
      xAxisKey: "month" as const,
      label: "Mes",
    },
  }

  return (
    <div className="space-y-6">
      {/* Estadísticas de Ventas */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Ventas Totales</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(stats.totalSales)}</div>
            <p className={`text-xs ${stats.percentageChange >= 0 ? "text-green-600" : "text-red-600"}`}>
              {stats.percentageChange >= 0 ? "+" : ""}{stats.percentageChange}% vs período anterior
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Promedio por Período</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(stats.averageSales)}</div>
            <p className="text-xs text-muted-foreground">Promedio de ventas</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Órdenes</CardTitle>
            <ShoppingCart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalOrders}</div>
            <p className="text-xs text-muted-foreground">Órdenes entregadas</p>
          </CardContent>
        </Card>
      </div>

      {/* Gráficos */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Gráfico de Ventas</span>
            <Tabs value={period} onValueChange={(v) => setPeriod(v as "day" | "week" | "month")}>
              <TabsList>
                <TabsTrigger value="day">Día</TabsTrigger>
                <TabsTrigger value="week">Semana</TabsTrigger>
                <TabsTrigger value="month">Mes</TabsTrigger>
              </TabsList>
            </Tabs>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <ComposedChart data={data as any}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis
                dataKey={chartConfig[period].xAxisKey}
                angle={-45}
                textAnchor="end"
                height={100}
                interval={Math.max(0, Math.floor(data.length / 8) - 1)}
                tick={{ fontSize: 12 }}
              />
              <YAxis
                yAxisId="left"
                label={{ value: "Venta ($)", angle: -90, position: "insideLeft" }}
                tickFormatter={(value) => `$${(value / 1000).toFixed(0)}k`}
              />
              <YAxis
                yAxisId="right"
                orientation="right"
                label={{ value: "Órdenes", angle: 90, position: "insideRight" }}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "rgba(0, 0, 0, 0.8)",
                  border: "1px solid rgba(255, 255, 255, 0.2)",
                  borderRadius: "8px",
                }}
                formatter={(value: any) => {
                  if (typeof value === "number" && value > 100) {
                    return formatCurrency(value)
                  }
                  return value
                }}
              />
              <Legend />
              <Bar yAxisId="left" dataKey="total" fill="#3b82f6" name="Ventas ($)" radius={[8, 8, 0, 0]} />
              <Line yAxisId="right" type="monotone" dataKey="orders" stroke="#ef4444" name="Órdenes (#)" strokeWidth={2} dot={false} />
            </ComposedChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Tabla de Detalles */}
      <Card>
        <CardHeader>
          <CardTitle>Detalles por Período</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-2 px-4 font-semibold">Período</th>
                  <th className="text-right py-2 px-4 font-semibold">Ventas</th>
                  <th className="text-right py-2 px-4 font-semibold">Órdenes</th>
                  <th className="text-right py-2 px-4 font-semibold">Promedio</th>
                </tr>
              </thead>
              <tbody>
                {data.map((item, index) => (
                  <tr key={index} className="border-b hover:bg-muted/50 transition-colors">
                    <td className="py-2 px-4">
                      {period === "day" && (item as DailySalesData).date}
                      {period === "week" && `${(item as WeeklySalesData).startDate} - ${(item as WeeklySalesData).endDate}`}
                      {period === "month" && (item as MonthlySalesData).month}
                    </td>
                    <td className="text-right py-2 px-4 font-semibold text-blue-600">{formatCurrency(item.total)}</td>
                    <td className="text-right py-2 px-4">{item.orders}</td>
                    <td className="text-right py-2 px-4">{formatCurrency(item.total / (item.orders || 1))}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
