import { Client } from "./types"
import React from "react"

export const getTierColor = (tier: string) => {
  switch (tier) {
    case "vip": return "bg-yellow-100 text-yellow-800 border-yellow-200"
    case "premium": return "bg-blue-100 text-blue-800 border-blue-200"
    default: return "bg-gray-100 text-gray-800 border-gray-200"
  }
}

export const formatCurrency = (amount: number) => {
  return amount.toLocaleString("es-MX", { style: "currency", currency: "MXN" })
}

export default function utils() { return null }
