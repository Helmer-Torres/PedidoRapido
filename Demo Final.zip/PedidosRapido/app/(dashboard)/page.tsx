"use client"

import { useState } from "react"
import { StatsGrid } from "@/components/dashboard/stats-grid"
import { OrdersTable } from "@/components/pedidos/orders-table"
import { OrderFilters } from "@/components/pedidos/order-filters"
import { ExportCSVButton } from "@/components/shared/export-csv-button"
import { dashboardStats, orders } from "@/lib/mock-data"
import { exportOrdersToCSV } from "@/lib/export-csv"
import type { OrderStatus } from "@/lib/types"

type FilterOption = OrderStatus | "todos"

export default function DashboardPage() {
  const [activeFilter, setActiveFilter] = useState<FilterOption>("todos")

  const filteredOrders = activeFilter === "todos" 
    ? orders 
    : orders.filter(order => order.status === activeFilter)

  const filterCounts = {
    todos: orders.length,
    pendiente: orders.filter(o => o.status === "pendiente").length,
    entregado: orders.filter(o => o.status === "entregado").length,
  }

  const handleExport = () => {
    exportOrdersToCSV(filteredOrders, `pedidos-${new Date().toISOString().split("T")[0]}`)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-foreground">Gestión de Pedidos</h1>
        <ExportCSVButton onExport={handleExport} />
      </div>

      <StatsGrid stats={dashboardStats} />

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-foreground">
            Detalle de Operaciones Hoy
          </h2>
          <OrderFilters 
            activeFilter={activeFilter} 
            onFilterChange={setActiveFilter}
            counts={filterCounts}
          />
        </div>

        <OrdersTable orders={filteredOrders} />
      </div>
    </div>
  )
}
