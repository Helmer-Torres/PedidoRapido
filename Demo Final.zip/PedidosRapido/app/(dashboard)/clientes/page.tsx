"use client"

import { useState } from "react"
import { Users } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { SearchInput } from "@/components/shared/search-input"
import { ExportCSVButton } from "@/components/shared/export-csv-button"
import { clients } from "@/lib/mock-data"
import { exportClientsToCSV } from "@/lib/export-csv"
import Link from "next/link"
import ClientCard from "./components/ClientCard"
import type { Client } from "./components/types"

export default function ClientesPage() {
  const [searchQuery, setSearchQuery] = useState("")

  const filteredClients = clients.filter((client: Client) =>
    searchQuery === "" ||
    client.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    client.email.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const handleExport = () => {
    exportClientsToCSV(filteredClients, `clientes-${new Date().toISOString().split("T")[0]}`)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-foreground">Clientes</h1>
        <div className="flex items-center gap-3">
          <SearchInput
            placeholder="Buscar cliente..."
            value={searchQuery}
            onChange={setSearchQuery}
          />
          <ExportCSVButton onExport={handleExport} />
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
        {filteredClients.map((client: Client) => (
          <Link key={client.id} href={`/clientes/${client.id}`}>
            <Card className="hover:border-primary/50 transition-colors cursor-pointer">
              <CardContent className="p-4">
                <ClientCard client={client} />
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      {filteredClients.length === 0 && (
        <div className="text-center py-12">
          <Users className="h-12 w-12 mx-auto text-muted-foreground/50" />
          <p className="mt-4 text-muted-foreground">No se encontraron clientes.</p>
        </div>
      )}
    </div>
  )
}
