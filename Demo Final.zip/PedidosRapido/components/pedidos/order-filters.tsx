"use client"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import type { OrderStatus } from "@/lib/types"

type FilterOption = OrderStatus | "todos"

interface OrderFiltersProps {
  activeFilter: FilterOption
  onFilterChange: (filter: FilterOption) => void
  counts?: {
    todos: number
    pendiente: number
    en_proceso?: number
    entregado: number
  }
}

const filters: { value: FilterOption; label: string }[] = [
  { value: "todos", label: "Todos" },
  { value: "pendiente", label: "Pendientes" },
  { value: "entregado", label: "Entregados" },
]

export function OrderFilters({ activeFilter, onFilterChange, counts }: OrderFiltersProps) {
  return (
    <div className="flex items-center gap-1 rounded-lg border border-border bg-muted/50 p-1">
      {filters.map((filter) => (
        <Button
          key={filter.value}
          variant={activeFilter === filter.value ? "default" : "ghost"}
          size="sm"
          onClick={() => onFilterChange(filter.value)}
          className={cn(
            "h-7 px-3 text-xs",
            activeFilter === filter.value && "bg-background shadow-sm"
          )}
        >
          {filter.label}
          {counts && counts[filter.value] !== undefined && (
            <span className="ml-1.5 text-muted-foreground">
              ({counts[filter.value]})
            </span>
          )}
        </Button>
      ))}
    </div>
  )
}
