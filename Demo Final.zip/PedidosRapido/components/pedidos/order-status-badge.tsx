import { cn } from "@/lib/utils"
import type { OrderStatus } from "@/lib/types"

interface OrderStatusBadgeProps {
  status: OrderStatus
  className?: string
}

const statusConfig: Record<OrderStatus, { label: string; className: string }> = {
  pendiente: {
    label: "Pendiente",
    className: "bg-red-100 text-red-700 border-red-200",
  },
  en_proceso: {
    label: "En Proceso",
    className: "bg-yellow-100 text-yellow-700 border-yellow-200",
  },
  entregado: {
    label: "Entregado",
    className: "bg-green-100 text-green-700 border-green-200",
  },
}

export function OrderStatusBadge({ status, className }: OrderStatusBadgeProps) {
  const config = statusConfig[status]

  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium",
        config.className,
        className
      )}
    >
      {config.label}
    </span>
  )
}
