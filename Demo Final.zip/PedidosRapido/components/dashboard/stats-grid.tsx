import { StatsCard } from "./stats-card"
import type { DashboardStats } from "@/lib/types"

interface StatsGridProps {
  stats: DashboardStats
}

export function StatsGrid({ stats }: StatsGridProps) {
  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
      <StatsCard
        title="Pedidos Entregados"
        value={stats.deliveredOrders}
        change={stats.ordersTodayChange}
        changeLabel="hoy"
      />
      <StatsCard
        title="Total Cobrado"
        value={`$${stats.totalCollected.toLocaleString("es-MX", { minimumFractionDigits: 2 })}`}
        subtitle="Corte parcial de caja"
      />
      <StatsCard
        title="Tasa de Entrega"
        value={`${stats.deliveryRate}%`}
        subtitle={`Promedio últimos ${stats.deliveryRateAvgDays} días`}
      />
      <StatsCard
        title="Total Hoy"
        value={stats.ordersToday}
        change={stats.ordersTodayChange}
      />
    </div>
  )
}
