"use client"

import { use } from "react"
import Link from "next/link"
import { ArrowLeft, Mail, Phone, MapPin, Calendar, Download, Filter } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Breadcrumbs } from "@/components/layout/breadcrumbs"
import { OrderStatusBadge } from "@/components/pedidos/order-status-badge"
import { getClientById, getOrdersByClientId } from "@/lib/mock-data"
import { notFound } from "next/navigation"

interface ClienteDetallePageProps {
  params: Promise<{ id: string }>
}

export default function ClienteDetallePage({ params }: ClienteDetallePageProps) {
  const { id } = use(params)
  const client = getClientById(id)
  const clientOrders = getOrdersByClientId(id)

  if (!client) {
    notFound()
  }

  const formatCurrency = (amount: number) => {
    return amount.toLocaleString("es-MX", { style: "currency", currency: "MXN" })
  }

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString("es-MX", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    })
  }

  const getTierColor = (tier: string) => {
    switch (tier) {
      case "vip": return "bg-yellow-100 text-yellow-800 border-yellow-200"
      case "premium": return "bg-blue-100 text-blue-800 border-blue-200"
      default: return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const memberSinceYear = new Date(client.memberSince).getFullYear()

  return (
    <div className="space-y-6">
      <Breadcrumbs items={[
        { label: "Admin", href: "/" },
        { label: "Clientes", href: "/clientes" },
        { label: "Historial de Cliente" }
      ]} />

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* Perfil del Cliente */}
        <div className="space-y-4">
          <Card>
            <CardContent className="p-6 text-center">
              <div className="relative inline-block">
                <Avatar className="h-24 w-24 mx-auto">
                  <AvatarImage src={client.avatar} alt={client.name} />
                  <AvatarFallback className="text-2xl">
                    {client.name.split(" ").map(n => n[0]).join("").slice(0, 2)}
                  </AvatarFallback>
                </Avatar>
                <span className="absolute bottom-0 right-0 h-5 w-5 bg-green-500 border-2 border-background rounded-full" />
              </div>
              
              <h2 className="mt-4 text-xl font-bold">{client.name}</h2>
              <p className="text-sm text-muted-foreground">
                Cliente {client.tier.toUpperCase()} desde {memberSinceYear}
              </p>

              <div className="mt-6 space-y-3 text-left">
                <div className="flex items-center gap-3 text-sm">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                  <span>{client.email}</span>
                </div>
                <div className="flex items-center gap-3 text-sm">
                  <Phone className="h-4 w-4 text-muted-foreground" />
                  <span>{client.phone}</span>
                </div>
                <div className="flex items-center gap-3 text-sm">
                  <MapPin className="h-4 w-4 text-muted-foreground" />
                  <span>{client.location}</span>
                </div>
              </div>

              <Button className="w-full mt-6" variant="outline">
                Editar Perfil
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Estadísticas e Historial */}
        <div className="lg:col-span-2 space-y-6">
          {/* Stats */}
          <div className="grid grid-cols-3 gap-4">
            <Card>
              <CardContent className="p-4">
                <p className="text-sm text-muted-foreground">Total Gastado</p>
                <p className="text-2xl font-bold text-primary">{formatCurrency(client.totalSpent)}</p>
                <p className="text-xs text-green-600">+12% vs año pasado</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <p className="text-sm text-muted-foreground">Pedidos Totales</p>
                <p className="text-2xl font-bold">{client.totalOrders}</p>
                <p className="text-xs text-muted-foreground">Promedio: 3.5 al mes</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <p className="text-sm text-muted-foreground">Última Compra</p>
                <p className="text-2xl font-bold">{client.lastOrderDate ? formatDate(client.lastOrderDate) : "N/A"}</p>
                <p className="text-xs text-muted-foreground">Hace 4 días</p>
              </CardContent>
            </Card>
          </div>

          {/* Historial de Pedidos */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-base">Historial de Pedidos</CardTitle>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm">
                  <Filter className="h-4 w-4 mr-2" />
                  Filtrar
                </Button>
                <Button variant="outline" size="sm">
                  <Download className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID Pedido</TableHead>
                    <TableHead>Fecha</TableHead>
                    <TableHead>Estado</TableHead>
                    <TableHead>Productos</TableHead>
                    <TableHead className="text-right">Monto Total</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {clientOrders.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center py-8">
                        Este cliente no tiene pedidos registrados.
                      </TableCell>
                    </TableRow>
                  ) : (
                    clientOrders.map((order) => (
                      <TableRow key={order.id}>
                        <TableCell>
                          <Link href={`/pedidos/${order.id}`} className="font-medium text-primary hover:underline">
                            #{order.id}
                          </Link>
                        </TableCell>
                        <TableCell>{formatDate(order.createdAt)}</TableCell>
                        <TableCell>
                          <OrderStatusBadge status={order.status} />
                        </TableCell>
                        <TableCell className="max-w-[200px] truncate">
                          {order.products.map(p => p.name).join(", ")}
                        </TableCell>
                        <TableCell className="text-right font-medium">
                          {formatCurrency(order.total)}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
