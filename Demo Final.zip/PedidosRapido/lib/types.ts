
type OrderStatus = "pendiente" | "en_proceso" | "entregado"


interface OrderProduct {
  id: string
  name: string
  quantity: number
  unitPrice: number
  subtotal: number
}


interface Order {
  id: string
  clientId: string
  clientName: string
  products: OrderProduct[]
  subtotal: number
  tax: number
  total: number
  status: OrderStatus
  notes?: string
  createdAt: Date
  updatedAt: Date
}


type ClientTier = "regular" | "premium" | "vip"


interface Client {
  id: string
  name: string
  email: string
  phone: string
  location: string
  avatar?: string
  memberSince: Date
  tier: ClientTier
  totalSpent: number
  totalOrders: number
  lastOrderDate?: Date
}


interface Product {
  id: string
  name: string
  price: number
  category: string
  stock: number
}


interface DashboardStats {
  ordersToday: number
  ordersTodayChange: number
  totalCollected: number
  deliveryRate: number
  deliveryRateAvgDays: number
  pendingOrders: number
  inProcessOrders: number
  deliveredOrders: number
}


interface OrderFilters {
  status?: OrderStatus | "todos"
  search?: string
  dateRange?: "hoy" | "semana" | "mes" | "todos"
}


interface PaginationConfig {
  page: number
  pageSize: number
  totalItems: number
  totalPages: number
}