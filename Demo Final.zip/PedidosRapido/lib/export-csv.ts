import type { Order, Client } from "./types"


export function exportToCSV<T extends Record<string, unknown>>(
  data: T[],
  columns: { key: keyof T; label: string }[],
  filename: string
): void {
  if (data.length === 0) {
    console.warn("No hay datos para exportar")
    return
  }

  
  const headers = columns.map(col => col.label).join(",")


  const rows = data.map(item => {
    return columns
      .map(col => {
        const value = item[col.key]
        // Escapar valores con comas o comillas
        if (typeof value === "string" && (value.includes(",") || value.includes('"'))) {
          return `"${value.replace(/"/g, '""')}"`
        }
        // Formatear fechas
        if (value instanceof Date) {
          return value.toLocaleDateString("es-MX")
        }
        return String(value ?? "")
      })
      .join(",")
  })

  
  const csvContent = [headers, ...rows].join("\n")

 
  const blob = new Blob(["\ufeff" + csvContent], { type: "text/csv;charset=utf-8;" })
  const link = document.createElement("a")
  const url = URL.createObjectURL(blob)

  link.setAttribute("href", url)
  link.setAttribute("download", `${filename}.csv`)
  link.style.visibility = "hidden"
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
  URL.revokeObjectURL(url)
}


export function exportOrdersToCSV(orders: Order[], filename = "pedidos"): void {
  const formattedOrders = orders.map(order => ({
    ...order,
    createdAt: order.createdAt,
    updatedAt: order.updatedAt,
    products: order.products.map(p => p.name).join("; "),
    statusLabel: getStatusLabel(order.status),
  }))

  exportToCSV(formattedOrders, [
    { key: "id", label: "ID Pedido" },
    { key: "clientName", label: "Cliente" },
    { key: "products", label: "Productos" },
    { key: "subtotal", label: "Subtotal" },
    { key: "tax", label: "Impuestos" },
    { key: "total", label: "Total" },
    { key: "statusLabel", label: "Estado" },
    { key: "createdAt", label: "Fecha Creación" },
    { key: "notes", label: "Notas" },
  ], filename)
}


export function exportClientsToCSV(clients: Client[], filename = "clientes"): void {
  const formattedClients = clients.map(client => ({
    ...client,
    memberSince: client.memberSince,
    lastOrderDate: client.lastOrderDate,
    tierLabel: getTierLabel(client.tier),
  }))

  exportToCSV(formattedClients, [
    { key: "id", label: "ID Cliente" },
    { key: "name", label: "Nombre" },
    { key: "email", label: "Email" },
    { key: "phone", label: "Teléfono" },
    { key: "location", label: "Ubicación" },
    { key: "tierLabel", label: "Nivel" },
    { key: "totalSpent", label: "Total Gastado" },
    { key: "totalOrders", label: "Total Pedidos" },
    { key: "memberSince", label: "Cliente Desde" },
    { key: "lastOrderDate", label: "Última Compra" },
  ], filename)
}


function getStatusLabel(status: Order["status"]): string {
  const labels: Record<Order["status"], string> = {
    pendiente: "Pendiente",
    en_proceso: "En Proceso",
    entregado: "Entregado",
  }
  return labels[status]
}

function getTierLabel(tier: Client["tier"]): string {
  const labels: Record<Client["tier"], string> = {
    regular: "Regular",
    premium: "Premium",
    vip: "VIP",
  }
  return labels[tier]
}
