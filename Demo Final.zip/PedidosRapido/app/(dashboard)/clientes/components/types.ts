export type Client = {
  id: string
  name: string
  avatar?: string
  email: string
  phone?: string
  location?: string
  tier: string
  totalOrders: number
  totalSpent: number
}
