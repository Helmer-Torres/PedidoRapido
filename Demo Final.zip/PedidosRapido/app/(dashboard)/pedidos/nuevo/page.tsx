"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, Plus, Trash2, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { OrderStatusBadge } from "@/components/pedidos/order-status-badge"
import { Breadcrumbs } from "@/components/layout/breadcrumbs"
import { products } from "@/lib/mock-data"

interface ProductLine {
  productId: string
  quantity: number
  unitPrice: number
  subtotal: number
}

export default function NuevoPedidoPage() {
  const [clientName, setClientName] = useState("")
  const [clientId, setClientId] = useState("")
  const [productLines, setProductLines] = useState<ProductLine[]>([
    { productId: "", quantity: 1, unitPrice: 0, subtotal: 0 }
  ])
  const [notes, setNotes] = useState("")

  const TAX_RATE = 0.16

  const addProductLine = () => {
    setProductLines([
      ...productLines,
      { productId: "", quantity: 1, unitPrice: 0, subtotal: 0 }
    ])
  }

  const removeProductLine = (index: number) => {
    if (productLines.length > 1) {
      setProductLines(productLines.filter((_, i) => i !== index))
    }
  }

  const updateProductLine = (index: number, field: keyof ProductLine, value: string | number) => {
    const updated = [...productLines]
    if (field === "productId") {
      const product = products.find(p => p.id === value)
      updated[index] = {
        ...updated[index],
        productId: value as string,
        unitPrice: product?.price || 0,
        subtotal: (product?.price || 0) * updated[index].quantity
      }
    } else if (field === "quantity") {
      const qty = Number(value) || 1
      updated[index] = {
        ...updated[index],
        quantity: qty,
        subtotal: updated[index].unitPrice * qty
      }
    }
    setProductLines(updated)
  }

  const subtotal = productLines.reduce((sum, line) => sum + line.subtotal, 0)
  const tax = subtotal * TAX_RATE
  const total = subtotal + tax

  const formatCurrency = (amount: number) => {
    return amount.toLocaleString("es-MX", { style: "currency", currency: "MXN" })
  }

  return (
    <div className="space-y-6">
      <Breadcrumbs items={[
        { label: "Pedidos", href: "/pedidos" },
        { label: "Nuevo Registro" }
      ]} />

      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-foreground">Registro de Pedido</h1>
        <div className="flex items-center gap-2">
          <Button variant="outline" asChild>
            <Link href="/pedidos">
              Cancelar
            </Link>
          </Button>
          <Button className="bg-primary hover:bg-primary/90">
            Guardar Pedido
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-6">
          {/* Información del Cliente */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <User className="h-4 w-4" />
                Información del Cliente
              </CardTitle>
            </CardHeader>
            <CardContent className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="clientName">Nombre del Cliente</Label>
                <Input
                  id="clientName"
                  placeholder="Ej. Juan Pérez"
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="clientId">Número de Identificación</Label>
                <Input
                  id="clientId"
                  placeholder="Ej. 12345678-9"
                  value={clientId}
                  onChange={(e) => setClientId(e.target.value)}
                />
              </div>
            </CardContent>
          </Card>

          {/* Detalle de Productos */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-base">Detalle de Productos</CardTitle>
              <Button variant="ghost" size="sm" onClick={addProductLine} className="gap-1 text-primary">
                <Plus className="h-4 w-4" />
                Añadir Producto
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-12 gap-2 text-sm font-medium text-muted-foreground">
                  <div className="col-span-5">Producto</div>
                  <div className="col-span-2">Cantidad</div>
                  <div className="col-span-2">Precio Unit.</div>
                  <div className="col-span-2">Subtotal</div>
                  <div className="col-span-1"></div>
                </div>
                
                {productLines.map((line, index) => (
                  <div key={index} className="grid grid-cols-12 gap-2 items-center">
                    <div className="col-span-5">
                      <Select
                        value={line.productId}
                        onValueChange={(value) => updateProductLine(index, "productId", value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Seleccionar producto..." />
                        </SelectTrigger>
                        <SelectContent>
                          {products.map((product) => (
                            <SelectItem key={product.id} value={product.id}>
                              {product.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="col-span-2">
                      <Input
                        type="number"
                        min={1}
                        value={line.quantity}
                        onChange={(e) => updateProductLine(index, "quantity", e.target.value)}
                      />
                    </div>
                    <div className="col-span-2">
                      <Input value={formatCurrency(line.unitPrice)} disabled />
                    </div>
                    <div className="col-span-2">
                      <Input value={formatCurrency(line.subtotal)} disabled />
                    </div>
                    <div className="col-span-1 flex justify-center">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-destructive hover:text-destructive"
                        onClick={() => removeProductLine(index)}
                        disabled={productLines.length === 1}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          {/* Estado del Registro */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Estado del Registro</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <OrderStatusBadge status="pendiente" />
              <p className="text-sm text-muted-foreground">Estado Inicial Automático</p>
            </CardContent>
          </Card>

          {/* Resumen de Pago */}
          <Card className="bg-primary text-primary-foreground">
            <CardHeader>
              <CardTitle className="text-base text-primary-foreground">Resumen de Pago</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-primary-foreground/80">Subtotal</span>
                <span>{formatCurrency(subtotal)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-primary-foreground/80">Impuestos (16%)</span>
                <span>{formatCurrency(tax)}</span>
              </div>
              <div className="border-t border-primary-foreground/20 pt-3">
                <div className="flex justify-between font-bold text-lg">
                  <span>Total a Pagar</span>
                  <span>{formatCurrency(total)}</span>
                </div>
              </div>
              <p className="text-xs text-primary-foreground/70 flex items-center gap-1">
                El total se recalcula automáticamente al modificar productos o cantidades.
              </p>
            </CardContent>
          </Card>

          {/* Notas Adicionales */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Notas Adicionales</CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                placeholder="Observaciones sobre la entrega o el pedido..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={4}
              />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
