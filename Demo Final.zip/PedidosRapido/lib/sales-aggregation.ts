import type { Order } from "./types"
import { format, startOfDay, startOfWeek } from "date-fns"
import { es } from "date-fns/locale"

export interface DailySalesData {
  date: string
  total: number
  orders: number
  day: string
}

export interface WeeklySalesData {
  week: string
  total: number
  orders: number
  startDate: string
  endDate: string
}

export interface MonthlySalesData {
  month: string
  total: number
  orders: number
  year: number
}

export interface SalesStats {
  totalSales: number
  averageSales: number
  totalOrders: number
  percentageChange: number
}


export function aggregateSalesByDay(orders: Order[], days: number = 30): DailySalesData[] {
  const today = new Date()
  const startDate = new Date(today)
  startDate.setDate(today.getDate() - days)
  

  const dateMap = new Map<string, { total: number; count: number }>()
  
 
  let currentDate = startOfDay(startDate)
  while (currentDate <= today) {
    const dateStr = format(currentDate, "yyyy-MM-dd")
    dateMap.set(dateStr, { total: 0, count: 0 })
    currentDate = new Date(currentDate.getTime() + 24 * 60 * 60 * 1000)
  }
  
 
  orders.forEach((order) => {
    if (order.status === "entregado") {
      const dateStr = format(new Date(order.createdAt), "yyyy-MM-dd")
      if (dateMap.has(dateStr)) {
        const current = dateMap.get(dateStr)!
        current.total += order.total
        current.count += 1
      }
    }
  })
  

  const result: DailySalesData[] = []
  dateMap.forEach((value, date) => {
    result.push({
      date,
      total: Math.round(value.total * 100) / 100,
      orders: value.count,
      day: format(new Date(date), "EEE", { locale: es }),
    })
  })
  
  return result.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
}


export function aggregateSalesByWeek(orders: Order[], weeks: number = 12): WeeklySalesData[] {
  const today = new Date()
  const startDate = new Date(today)
  startDate.setDate(today.getDate() - weeks * 7)
  
  const weekMap = new Map<string, { total: number; count: number; startDate: Date; endDate: Date }>()
  
  orders.forEach((order) => {
    if (order.status === "entregado") {
      const weekStart = startOfWeek(new Date(order.createdAt), { weekStartsOn: 1 })
      const weekKey = format(weekStart, "yyyy-'W'ww")
      
      if (!weekMap.has(weekKey)) {
        const weekEnd = new Date(weekStart)
        weekEnd.setDate(weekStart.getDate() + 6)
        weekMap.set(weekKey, {
          total: 0,
          count: 0,
          startDate: weekStart,
          endDate: weekEnd,
        })
      }
      
      const current = weekMap.get(weekKey)!
      current.total += order.total
      current.count += 1
    }
  })
  
  const result: WeeklySalesData[] = []
  weekMap.forEach((value, week) => {
    result.push({
      week,
      total: Math.round(value.total * 100) / 100,
      orders: value.count,
      startDate: format(value.startDate, "MMM d"),
      endDate: format(value.endDate, "MMM d"),
    })
  })
  
  return result.sort((a, b) => a.week.localeCompare(b.week))
}


export function aggregateSalesByMonth(orders: Order[], months: number = 12): MonthlySalesData[] {
  const monthMap = new Map<string, { total: number; count: number; year: number }>()
  
  orders.forEach((order) => {
    if (order.status === "entregado") {
      const date = new Date(order.createdAt)
      const monthKey = format(date, "yyyy-MM")
      const year = date.getFullYear()
      
      if (!monthMap.has(monthKey)) {
        monthMap.set(monthKey, {
          total: 0,
          count: 0,
          year,
        })
      }
      
      const current = monthMap.get(monthKey)!
      current.total += order.total
      current.count += 1
    }
  })
  
  const result: MonthlySalesData[] = []
  monthMap.forEach((value, month) => {
    const [year, monthNum] = month.split("-")
    result.push({
      month: format(new Date(parseInt(year), parseInt(monthNum) - 1), "MMM yyyy"),
      total: Math.round(value.total * 100) / 100,
      orders: value.count,
      year: value.year,
    })
  })
  
  return result.sort((a, b) => a.year - b.year || a.month.localeCompare(b.month))
}


export function calculateSalesStats(
  data: DailySalesData[] | WeeklySalesData[] | MonthlySalesData[],
  previousData?: DailySalesData[] | WeeklySalesData[] | MonthlySalesData[]
): SalesStats {
  const totalSales = data.reduce((sum, item) => sum + item.total, 0)
  const totalOrders = data.reduce((sum, item) => sum + item.orders, 0)
  const averageSales = data.length > 0 ? totalSales / data.length : 0
  
  let percentageChange = 0
  if (previousData && previousData.length > 0) {
    const previousTotal = previousData.reduce((sum, item) => sum + item.total, 0)
    if (previousTotal > 0) {
      percentageChange = ((totalSales - previousTotal) / previousTotal) * 100
    }
  }
  
  return {
    totalSales: Math.round(totalSales * 100) / 100,
    averageSales: Math.round(averageSales * 100) / 100,
    totalOrders,
    percentageChange: Math.round(percentageChange * 100) / 100,
  }
}


export function formatCurrency(value: number): string {
  return new Intl.NumberFormat("es-MX", {
    style: "currency",
    currency: "MXN",
  }).format(value)
}
