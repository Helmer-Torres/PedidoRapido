"use client"

import React from "react"
import { Mail, Phone, MapPin, Badge as LucideBadge } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { CardContent } from "@/components/ui/card"
import { Client } from "./types"
import { getTierColor, formatCurrency } from "./utils"

export function ClientCard({ client }: { client: Client }) {
  return (
    <div className="flex items-start gap-4">
      <Avatar className="h-12 w-12">
        <AvatarImage src={client.avatar} alt={client.name} />
        <AvatarFallback>
          {client.name.split(" ").map(n => n[0]).join("").slice(0, 2)}
        </AvatarFallback>
      </Avatar>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <h3 className="font-semibold truncate">{client.name}</h3>
          <Badge variant="outline" className={getTierColor(client.tier)}>
            {client.tier.toUpperCase()}
          </Badge>
        </div>
        <div className="mt-2 space-y-1 text-sm text-muted-foreground">
          <div className="flex items-center gap-2">
            <Mail className="h-3 w-3" />
            <span className="truncate">{client.email}</span>
          </div>
          <div className="flex items-center gap-2">
            <Phone className="h-3 w-3" />
            <span>{client.phone}</span>
          </div>
          <div className="flex items-center gap-2">
            <MapPin className="h-3 w-3" />
            <span>{client.location}</span>
          </div>
        </div>
        <div className="mt-3 flex items-center justify-between text-sm">
          <span className="text-muted-foreground">{client.totalOrders} pedidos</span>
          <span className="font-medium text-primary">{formatCurrency(client.totalSpent)}</span>
        </div>
      </div>
    </div>
  )
}

export default ClientCard
