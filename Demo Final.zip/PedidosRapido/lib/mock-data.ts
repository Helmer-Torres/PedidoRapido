import type { Order, Client, Product, DashboardStats } from "./types"

export const products: Product[] = [
  { id: "PROD-001", name: "Laptop XPS 13", price: 1200.00, category: "Electrónica", stock: 15 },
  { id: "PROD-002", name: "Mouse Inalámbrico", price: 45.00, category: "Accesorios", stock: 50 },
  { id: "PROD-003", name: "Monitor 27\" 4K", price: 450.00, category: "Electrónica", stock: 8 },
  { id: "PROD-004", name: "Cable HDMI", price: 25.00, category: "Accesorios", stock: 100 },
  { id: "PROD-005", name: "Teclado Mecánico RGB", price: 120.00, category: "Accesorios", stock: 25 },
  { id: "PROD-006", name: "Webcam HD 1080p", price: 89.00, category: "Electrónica", stock: 30 },
  { id: "PROD-007", name: "Audífonos Bluetooth", price: 150.00, category: "Audio", stock: 20 },
  { id: "PROD-008", name: "Hub USB-C", price: 65.00, category: "Accesorios", stock: 40 },
]

export const clients: Client[] = [
  {
    id: "CLI-001",
    name: "Claudia Domínguez",
    email: "claudia.d@email.com",
    phone: "+52 55 1234 5678",
    location: "CDMX, México",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop&crop=face",
    memberSince: new Date("2021-03-15"),
    tier: "vip",
    totalSpent: 24500.00,
    totalOrders: 42,
    lastOrderDate: new Date("2023-10-12"),
  },
  {
    id: "CLI-002",
    name: "Carlos Rodríguez",
    email: "carlos.r@email.com",
    phone: "+52 55 9876 5432",
    location: "Guadalajara, México",
    memberSince: new Date("2022-01-20"),
    tier: "premium",
    totalSpent: 8500.00,
    totalOrders: 15,
    lastOrderDate: new Date("2023-10-15"),
  },
  {
    id: "CLI-003",
    name: "Mariana Silva",
    email: "mariana.s@email.com",
    phone: "+52 55 5555 1234",
    location: "Monterrey, México",
    memberSince: new Date("2023-02-10"),
    tier: "regular",
    totalSpent: 1250.00,
    totalOrders: 5,
    lastOrderDate: new Date("2023-10-14"),
  },
  {
    id: "CLI-004",
    name: "Juan Pablo López",
    email: "juanp.l@email.com",
    phone: "+52 55 4444 5678",
    location: "Puebla, México",
    memberSince: new Date("2022-06-05"),
    tier: "premium",
    totalSpent: 12300.00,
    totalOrders: 28,
    lastOrderDate: new Date("2023-10-13"),
  },
  {
    id: "CLI-005",
    name: "Elena Mendoza",
    email: "elena.m@email.com",
    phone: "+52 55 3333 9876",
    location: "Querétaro, México",
    memberSince: new Date("2023-05-18"),
    tier: "regular",
    totalSpent: 450.00,
    totalOrders: 3,
    lastOrderDate: new Date("2023-10-12"),
  },
  {
    id: "CLI-006",
    name: "Ricardo Alarcón",
    email: "ricardo.a@email.com",
    phone: "+52 55 2222 1111",
    location: "CDMX, México",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
    memberSince: new Date("2021-11-30"),
    tier: "premium",
    totalSpent: 15800.00,
    totalOrders: 35,
    lastOrderDate: new Date("2023-10-15"),
  },
  {
    id: "CLI-007",
    name: "Sofía Méndez",
    email: "sofia.m@email.com",
    phone: "+52 55 7777 8888",
    location: "Cancún, México",
    memberSince: new Date("2023-08-01"),
    tier: "regular",
    totalSpent: 320.00,
    totalOrders: 2,
    lastOrderDate: new Date("2023-10-14"),
  },
  {
    id: "CLI-008",
    name: "Marcos Ruiz",
    email: "marcos.r@email.com",
    phone: "+52 55 6666 4444",
    location: "León, México",
    memberSince: new Date("2023-07-22"),
    tier: "regular",
    totalSpent: 180.00,
    totalOrders: 1,
    lastOrderDate: new Date("2023-10-10"),
  },
]

export const orders: Order[] = [
  {
    id: "ORD-2024-001",
    clientId: "CLI-002",
    clientName: "Carlos Rodríguez",
    products: [
      { id: "PROD-001", name: "Laptop XPS 13", quantity: 1, unitPrice: 1200.00, subtotal: 1200.00 },
    ],
    subtotal: 1200.00,
    tax: 192.00,
    total: 1392.00,
    status: "entregado",
    createdAt: new Date("2023-10-15T09:30:00"),
    updatedAt: new Date("2023-10-15T14:00:00"),
  },
  {
    id: "ORD-2024-002",
    clientId: "CLI-003",
    clientName: "Mariana Silva",
    products: [
      { id: "PROD-002", name: "Mouse Inalámbrico", quantity: 2, unitPrice: 45.00, subtotal: 90.00 },
    ],
    subtotal: 90.00,
    tax: 14.40,
    total: 104.40,
    status: "pendiente",
    notes: "Entregar en horario de oficina",
    createdAt: new Date("2023-10-15T10:15:00"),
    updatedAt: new Date("2023-10-15T10:15:00"),
  },
  {
    id: "ORD-2024-003",
    clientId: "CLI-004",
    clientName: "Juan Pablo López",
    products: [
      { id: "PROD-003", name: "Monitor 27\" 4K", quantity: 1, unitPrice: 450.00, subtotal: 450.00 },
    ],
    subtotal: 450.00,
    tax: 72.00,
    total: 522.00,
    status: "entregado",
    createdAt: new Date("2023-10-14T16:45:00"),
    updatedAt: new Date("2023-10-15T11:30:00"),
  },
  {
    id: "ORD-2024-004",
    clientId: "CLI-005",
    clientName: "Elena Mendoza",
    products: [
      { id: "PROD-005", name: "Teclado Mecánico RGB", quantity: 1, unitPrice: 120.00, subtotal: 120.00 },
    ],
    subtotal: 120.00,
    tax: 19.20,
    total: 139.20,
    status: "pendiente",
    createdAt: new Date("2023-10-15T11:00:00"),
    updatedAt: new Date("2023-10-15T11:00:00"),
  },
  {
    id: "ORD-4209",
    clientId: "CLI-006",
    clientName: "Ricardo Alarcón",
    products: [
      { id: "PROD-001", name: "Laptop XPS 13", quantity: 1, unitPrice: 1200.00, subtotal: 1200.00 },
      { id: "PROD-002", name: "Mouse Inalámbrico", quantity: 1, unitPrice: 45.00, subtotal: 45.00 },
    ],
    subtotal: 1245.00,
    tax: 199.20,
    total: 1444.20,
    status: "pendiente",
    createdAt: new Date("2023-10-15T14:25:00"),
    updatedAt: new Date("2023-10-15T14:25:00"),
  },
  {
    id: "ORD-4210",
    clientId: "CLI-007",
    clientName: "Sofía Méndez",
    products: [
      { id: "PROD-002", name: "Mouse Inalámbrico", quantity: 1, unitPrice: 45.00, subtotal: 45.00 },
    ],
    subtotal: 45.00,
    tax: 7.20,
    total: 52.20,
    status: "en_proceso",
    createdAt: new Date("2023-10-15T14:10:00"),
    updatedAt: new Date("2023-10-15T14:30:00"),
  },
  {
    id: "ORD-4211",
    clientId: "CLI-004",
    clientName: "Juan Pérez",
    products: [
      { id: "PROD-006", name: "Webcam HD 1080p", quantity: 2, unitPrice: 89.00, subtotal: 178.00 },
      { id: "PROD-008", name: "Hub USB-C", quantity: 1, unitPrice: 65.00, subtotal: 65.00 },
    ],
    subtotal: 243.00,
    tax: 38.88,
    total: 281.88,
    status: "pendiente",
    createdAt: new Date("2023-10-15T14:05:00"),
    updatedAt: new Date("2023-10-15T14:05:00"),
  },
  {
    id: "ORD-4205",
    clientId: "CLI-006",
    clientName: "Elena Rose",
    products: [
      { id: "PROD-007", name: "Audífonos Bluetooth", quantity: 1, unitPrice: 150.00, subtotal: 150.00 },
    ],
    subtotal: 150.00,
    tax: 24.00,
    total: 174.00,
    status: "entregado",
    createdAt: new Date("2023-10-15T13:30:00"),
    updatedAt: new Date("2023-10-15T16:00:00"),
  },
  {
    id: "ORD-4212",
    clientId: "CLI-008",
    clientName: "Marcos Ruiz",
    products: [
      { id: "PROD-004", name: "Cable HDMI", quantity: 2, unitPrice: 25.00, subtotal: 50.00 },
    ],
    subtotal: 50.00,
    tax: 8.00,
    total: 58.00,
    status: "pendiente",
    createdAt: new Date("2023-10-15T13:15:00"),
    updatedAt: new Date("2023-10-15T13:15:00"),
  },
  {
    id: "ORD-9921",
    clientId: "CLI-001",
    clientName: "Claudia Domínguez",
    products: [
      { id: "PROD-001", name: "Laptop XPS 13", quantity: 1, unitPrice: 1200.00, subtotal: 1200.00 },
      { id: "PROD-002", name: "Mouse Inalámbrico", quantity: 1, unitPrice: 45.00, subtotal: 45.00 },
    ],
    subtotal: 1245.00,
    tax: 199.20,
    total: 1444.20,
    status: "entregado",
    createdAt: new Date("2023-10-12T10:00:00"),
    updatedAt: new Date("2023-10-12T15:30:00"),
  },
  {
    id: "ORD-9845",
    clientId: "CLI-001",
    clientName: "Claudia Domínguez",
    products: [
      { id: "PROD-003", name: "Monitor 27\" 4K", quantity: 1, unitPrice: 450.00, subtotal: 450.00 },
      { id: "PROD-004", name: "Cable HDMI", quantity: 2, unitPrice: 25.00, subtotal: 50.00 },
    ],
    subtotal: 500.00,
    tax: 80.00,
    total: 580.00,
    status: "en_proceso",
    createdAt: new Date("2023-09-28T11:20:00"),
    updatedAt: new Date("2023-09-28T14:00:00"),
  },
  {
    id: "ORD-9781",
    clientId: "CLI-001",
    clientName: "Claudia Domínguez",
    products: [
      { id: "PROD-005", name: "Teclado Mecánico RGB", quantity: 1, unitPrice: 120.00, subtotal: 120.00 },
    ],
    subtotal: 120.00,
    tax: 19.20,
    total: 139.20,
    status: "pendiente",
    createdAt: new Date("2023-08-15T09:45:00"),
    updatedAt: new Date("2023-08-15T09:45:00"),
  },
]

export const dashboardStats: DashboardStats = {
  ordersToday: 48,
  ordersTodayChange: 12,
  totalCollected: 1842.50,
  deliveryRate: 94.2,
  deliveryRateAvgDays: 7,
  pendingOrders: 12,
  inProcessOrders: 24,
  deliveredOrders: 12,
}

export function getOrderById(id: string): Order | undefined {
  return orders.find(order => order.id === id)
}

export function getClientById(id: string): Client | undefined {
  return clients.find(client => client.id === id)
}

export function getOrdersByClientId(clientId: string): Order[] {
  return orders.filter(order => order.clientId === clientId)
}

export function getOrdersByStatus(status: Order["status"]): Order[] {
  return orders.filter(order => order.status === status)
}

export function getTodayOrders(): Order[] {
  const today = new Date()
  today.setHours(0, 0, 0, 0)
  return orders.filter(order => {
    const orderDate = new Date(order.createdAt)
    orderDate.setHours(0, 0, 0, 0)
    return orderDate.getTime() === today.getTime()
  })
}
