"use client"

import { Download } from "lucide-react"
import { Button } from "@/components/ui/button"

interface ExportCSVButtonProps {
  onExport: () => void
  label?: string
  disabled?: boolean
}

export function ExportCSVButton({ 
  onExport, 
  label = "Exportar CSV",
  disabled = false 
}: ExportCSVButtonProps) {
  return (
    <Button
      variant="outline"
      size="sm"
      onClick={onExport}
      disabled={disabled}
      className="gap-2"
    >
      <Download className="h-4 w-4" />
      {label}
    </Button>
  )
}
