import { SalesChart } from "@/components/sales/SalesChart"
import { orders } from "@/lib/mock-data"

export default function ReportesPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-foreground">Reportes de Ventas</h1>
      <p className="text-muted-foreground">
        Análisis de ventas por período con tendencias y métricas de rendimiento
      </p>

      <SalesChart orders={orders} />
    </div>
  )
}
