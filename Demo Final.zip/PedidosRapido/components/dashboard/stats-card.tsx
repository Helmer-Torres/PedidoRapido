import { cn } from "@/lib/utils"
import { Card, CardContent } from "@/components/ui/card"

interface StatsCardProps {
  title: string
  value: string | number
  subtitle?: string
  change?: number
  changeLabel?: string
  className?: string
}

export function StatsCard({
  title,
  value,
  subtitle,
  change,
  changeLabel,
  className,
}: StatsCardProps) {
  const isPositive = change && change > 0
  const isNegative = change && change < 0

  return (
    <Card className={cn("", className)}>
      <CardContent className="p-4 lg:p-6">
        <p className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
          {title}
        </p>
        <div className="mt-2 flex items-baseline gap-2">
          <p className="text-2xl lg:text-3xl font-bold text-foreground">
            {value}
          </p>
          {change !== undefined && (
            <span
              className={cn(
                "text-sm font-medium",
                isPositive && "text-green-600",
                isNegative && "text-red-600",
                !isPositive && !isNegative && "text-muted-foreground"
              )}
            >
              {isPositive && "+"}
              {change}%{changeLabel && ` ${changeLabel}`}
            </span>
          )}
        </div>
        {subtitle && (
          <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p>
        )}
      </CardContent>
    </Card>
  )
}
